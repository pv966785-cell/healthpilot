# Firebase Console Login Setup

1. Firebase Console -> Authentication -> Sign-in method -> enable Email/Password (and Google if used).
2. Authentication -> Settings -> Authorized domains -> add mediisphere-7f3g.vercel.app (and localhost).
3. Deploy the current firestore.rules to the SAME database the app uses. The app uses the named database id in firebase-applet-config.json (firestoreDatabaseId), NOT "(default)". Deploy with: firebase deploy --only firestore:rules, and make sure firebase.json targets that database id.
4. Make sure firebase-applet-config.json is committed to the repo that Vercel builds, then redeploy on Vercel.
