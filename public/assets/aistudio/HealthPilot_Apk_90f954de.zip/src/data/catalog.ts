import { Medicine } from '../types';
import { SAMPLE_LAB_TESTS, getPatientPrice, formatINR, PRICE_MARKUP_PERCENT, LAB_TEST_CATEGORIES } from '../content';

export { SAMPLE_LAB_TESTS, getPatientPrice, formatINR, PRICE_MARKUP_PERCENT, LAB_TEST_CATEGORIES };
export const mockLabTests = SAMPLE_LAB_TESTS;


export const mockMedicines: Medicine[] = [
  {
    id: 'med-1',
    name: 'Glycomet-SR 500mg Tablet',
    salt: 'Metformin Hydrochloride (Extended Release)',
    category: 'Diabetes',
    price: 110,
    discountPrice: 95,
    requiresRx: true,
    manufacturer: 'USV Private Limited',
    uses: 'Used in the treatment of Type 2 Diabetes Mellitus to control blood glucose levels.',
    sideEffects: 'Nausea, diarrhea, stomach upset.',
    substitutes: ['Metformin ER 500mg', 'Gluformin SR 500mg'],
    inStock: true,
    stockCount: 140,
    expiryDate: '12/2027',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'med-2',
    name: 'Pan-40 Tablet',
    salt: 'Pantoprazole (40mg)',
    category: 'General',
    price: 168,
    discountPrice: 142,
    requiresRx: true,
    manufacturer: 'Alkem Laboratories',
    uses: 'Treatment of hyperacidity, GERD, heartburn, and stomach ulcers.',
    sideEffects: 'Headache, diarrhea, flatulence.',
    substitutes: ['Pantocid 40mg', 'Pansec 40mg'],
    inStock: true,
    stockCount: 85,
    expiryDate: '09/2027',
    imageUrl: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'med-3',
    name: 'Shelcal 500mg Tablet',
    salt: 'Calcium Carbonate + Vitamin D3',
    category: 'Wellness',
    price: 130,
    discountPrice: 115,
    requiresRx: false,
    manufacturer: 'Torrent Pharmaceuticals',
    uses: 'Calcium and Vitamin D3 supplement for bone health and joint support.',
    sideEffects: 'Constipation, mild gastric discomfort.',
    substitutes: ['Gemcal', 'Calcimax 500'],
    inStock: true,
    stockCount: 210,
    expiryDate: '03/2028',
    imageUrl: 'https://images.unsplash.com/photo-1550572017-edd951b55104?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'med-4',
    name: 'Liv.52 DS Syrup',
    salt: 'Ayurvedic Hepato-Protective Formulation',
    category: 'Ayurveda',
    price: 165,
    discountPrice: 150,
    requiresRx: false,
    manufacturer: 'The Himalaya Drug Company',
    uses: 'Improves liver function, appetite, and digestion.',
    sideEffects: 'None known when taken as directed.',
    substitutes: ['LivPro', 'Heptoglobin'],
    inStock: true,
    stockCount: 60,
    expiryDate: '01/2028',
    imageUrl: 'https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?auto=format&fit=crop&q=80&w=300'
  }
];
