import { CONTACT_EMAIL } from './config/constants';
import { 
  LabTest, Doctor, Medicine, LabBooking, DoctorAppointment, 
  PharmacyOrder, HealthRecord, AdminRoleConfig, AuditLog, 
  SupportTicket, PatientProfile, DoctorProfile, PharmacistProfile, 
  LabProfile, AdminProfile, FounderInfo, FamilyMember 
} from './types';

export const founderDetails: FounderInfo = {
  name: 'Praveen Verma',
  role: 'Founder & Director',
  phone: '9311601420',
  email: CONTACT_EMAIL,
  address: 'Sector-63, Noida, Uttar Pradesh, India - 201301',
  office: 'Sector-63, Noida, Uttar Pradesh, India - 201301'
};

export const mockFamilyMembers: FamilyMember[] = [];

// Clean initial patients store (populated via real patient registration)
export const initialPatients: PatientProfile[] = [];

export const initialDoctors: DoctorProfile[] = [
  {
    id: 'doc-1',
    name: 'Dr. Ananya Mukherjee',
    email: 'dr.ananya@healthpilot.demo',
    phone: '+91 98711 22334',
    role: 'doctor',
    status: 'Active',
    specialty: 'General Physician',
    qualification: 'MBBS, MD - General Medicine (AIIMS Delhi)',
    experienceYears: 14,
    councilRegistrationNumber: 'DMC/R/18492',
    hospitalOrClinic: 'Max Super Speciality Hospital, Noida',
    clinicAddress: 'Max Hospital, Sector 19, Noida',
    consultationFee: 499,
    languages: ['English', 'Hindi', 'Bengali'],
    bio: 'Senior consultant in primary medical care, infectious disease, and preventive chronic health management.',
    rating: 4.9,
    reviewCount: 428,
    isAvailableNow: true,
    avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300',
    documents: {
      degreeUrl: 'MD_AIIMS_Verification_Signed.pdf',
      licenceUrl: 'NMC_Medical_Council_ID_18492.pdf',
      photoUrl: 'Doctor_Photo_Verified.jpg'
    },
    createdAt: '15 Aug 2026'
  },
  {
    id: 'doc-2',
    name: 'Dr. Sameer Khan',
    email: 'dr.sameer@gmail.com',
    phone: '+91 99554 11223',
    role: 'doctor',
    status: 'Pending',
    specialty: 'Cardiologist',
    qualification: 'MBBS, MD, DM - Cardiology (King George Medical University)',
    experienceYears: 11,
    councilRegistrationNumber: 'UPMC/74921/2015',
    hospitalOrClinic: 'Metro Heart Institute, Sector 12, Noida',
    clinicAddress: 'Metro Hospital, Noida, UP',
    consultationFee: 899,
    languages: ['English', 'Hindi', 'Urdu'],
    bio: 'Interventional cardiologist specializing in coronary angioplasty, hypertension, and arrhythmia care.',
    rating: 4.8,
    reviewCount: 112,
    isAvailableNow: false,
    avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=300',
    documents: {
      degreeUrl: 'KGMU_DM_Cardiology_Degree.pdf',
      licenceUrl: 'UP_State_Medical_Council_Reg.pdf',
      photoUrl: 'Doctor_Profile_Upload.jpg'
    },
    createdAt: '16 Oct 2026'
  }
];

export const initialPharmacists: PharmacistProfile[] = [
  {
    id: 'pharma-1',
    name: 'Rajesh Gupta',
    email: 'rajesh.gupta@apollopharmacy.in',
    phone: '+91 98100 45678',
    role: 'pharmacist',
    status: 'Active',
    pharmacyName: 'Apollo Medicos & Healthcare Hub',
    drugLicenceNumber: 'DL-UP-NOI-20B-99120',
    gstNumber: '09AAACA1234F1Z5',
    pharmacyAddress: 'Shop 14, Central Market, Sector 63, Noida, UP',
    documents: {
      licenceUrl: 'Drug_Licence_20B_21B.pdf',
      gstCertUrl: 'GST_Reg_Certificate.pdf'
    },
    createdAt: '20 Aug 2026'
  },
  {
    id: 'pharma-2',
    name: 'Sunita Verma',
    email: 'sunita.pharma@gmail.com',
    phone: '+91 97180 88221',
    role: 'pharmacist',
    status: 'Pending',
    pharmacyName: 'Sunita Care Pharmacy',
    drugLicenceNumber: 'DL-UP-NOI-20B-77411',
    gstNumber: '09BBACB5432D1Z8',
    pharmacyAddress: 'Plot 45, B-Block Market, Sector 62, Noida, UP',
    documents: {
      licenceUrl: 'State_Drug_Controller_Licence.pdf',
      gstCertUrl: 'GST_Verification_Doc.pdf'
    },
    createdAt: '17 Oct 2026'
  }
];

export const initialLabs: LabProfile[] = [
  {
    id: 'lab-1',
    name: 'Dr. Manish Chawla',
    email: 'manish@healthpilotlabs.demo',
    phone: '+91 98990 12345',
    role: 'lab',
    status: 'Active',
    labName: 'HealthPilot Central Diagnostics & Pathology',
    accreditation: 'NABL',
    licenceNumber: 'NABL-MC-3420/2026',
    labAddress: 'Institutional Area, Sector 62, Noida, UP',
    documents: {
      accreditationCertUrl: 'NABL_Accreditation_Certificate.pdf',
      licenceUrl: 'Clinical_Establishment_Licence.pdf'
    },
    createdAt: '10 Aug 2026'
  },
  {
    id: 'lab-2',
    name: 'Kavita Sundaram',
    email: 'kavita@metropolislabs.in',
    phone: '+91 98115 67890',
    role: 'lab',
    status: 'Pending',
    labName: 'Metropolis Express Diagnostics',
    accreditation: 'ISO',
    licenceNumber: 'UP-CEA-2026-8819',
    labAddress: 'Shop 7, Main Commercial Complex, Sector 18, Noida, UP',
    documents: {
      accreditationCertUrl: 'ISO_15189_Cert.pdf',
      licenceUrl: 'UP_State_Health_Dept_Permit.pdf'
    },
    createdAt: '16 Oct 2026'
  }
];

export const initialAdmin: AdminProfile = {
  id: 'admin-1',
  name: 'Praveen Verma',
  email: 'admin@healthpilot.demo',
  phone: '+91 93116 01420',
  role: 'super_admin',
  status: 'Active',
  twoFactorEnabled: false,
  failedAttempts: 0,
  createdAt: '01 Jan 2026'
};


export const mockDoctors: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Ananya Mukherjee',
    specialty: 'General Physician',
    qualification: 'MBBS, MD - General Medicine (AIIMS Delhi)',
    experienceYears: 14,
    hospital: 'Max Super Speciality Hospital, Noida',
    rating: 4.9,
    reviewCount: 428,
    consultationFee: 499,
    languages: ['English', 'Hindi', 'Bengali'],
    nextAvailableSlot: 'Today, 04:30 PM',
    avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300',
    bio: 'Specialist in primary care, viral infections, lifestyle disorders, and geriatric health.'
  },
  {
    id: 'doc-2',
    name: 'Dr. Sameer Khan',
    specialty: 'Cardiologist',
    qualification: 'MBBS, MD, DM - Cardiology (KGMU)',
    experienceYears: 11,
    hospital: 'Metro Hospital, Noida',
    rating: 4.8,
    reviewCount: 112,
    consultationFee: 899,
    languages: ['English', 'Hindi', 'Urdu'],
    nextAvailableSlot: 'Tomorrow, 10:00 AM',
    avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=300',
    bio: 'Renowned cardiologist expert in preventive cardiology, hypertension, and heart failure management.'
  }
];

export const mockMedicines: Medicine[] = [
  {
    id: 'med-1',
    name: 'Glycomet-SR 500mg Tablet',
    salt: 'Metformin Hydrochloride (Extended Release)',
    category: 'Diabetes',
    price: 110,
    discountPrice: 95,
    requiresRx: true,
    manufacturer: 'USV Private Limited',
    uses: 'Used in the treatment of Type 2 Diabetes Mellitus to control blood glucose levels.',
    sideEffects: 'Nausea, diarrhea, stomach upset.',
    substitutes: ['Metformin ER 500mg', 'Gluformin SR 500mg'],
    inStock: true,
    stockCount: 140,
    expiryDate: '12/2027',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'med-2',
    name: 'Pan-40 Tablet',
    salt: 'Pantoprazole (40mg)',
    category: 'General',
    price: 168,
    discountPrice: 142,
    requiresRx: true,
    manufacturer: 'Alkem Laboratories',
    uses: 'Treatment of hyperacidity, GERD, heartburn, and stomach ulcers.',
    sideEffects: 'Headache, diarrhea, flatulence.',
    substitutes: ['Pantocid 40mg', 'Pansec 40mg'],
    inStock: true,
    stockCount: 85,
    expiryDate: '09/2027',
    imageUrl: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'med-3',
    name: 'Shelcal 500mg Tablet',
    salt: 'Calcium Carbonate + Vitamin D3',
    category: 'Wellness',
    price: 130,
    discountPrice: 115,
    requiresRx: false,
    manufacturer: 'Torrent Pharmaceuticals',
    uses: 'Calcium and Vitamin D3 supplement for bone health and joint support.',
    sideEffects: 'Constipation, mild gastric discomfort.',
    substitutes: ['Gemcal', 'Calcimax 500'],
    inStock: true,
    stockCount: 210,
    expiryDate: '03/2028',
    imageUrl: 'https://images.unsplash.com/photo-1550572017-edd951b55104?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'med-4',
    name: 'Liv.52 DS Syrup',
    salt: 'Ayurvedic Hepato-Protective Formulation',
    category: 'Ayurveda',
    price: 165,
    discountPrice: 150,
    requiresRx: false,
    manufacturer: 'The Himalaya Drug Company',
    uses: 'Improves liver function, appetite, and digestion.',
    sideEffects: 'None known when taken as directed.',
    substitutes: ['LivPro', 'Heptoglobin'],
    inStock: true,
    stockCount: 60,
    expiryDate: '01/2028',
    imageUrl: 'https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?auto=format&fit=crop&q=80&w=300'
  }
];

export const mockLabBookings: LabBooking[] = [
  {
    id: 'LB-9021',
    patientId: 'pat-101',
    patientName: 'Priya Sharma',
    patientPhone: '+91 98765 43210',
    testId: 'lt-1',
    testName: 'Comprehensive Full Body Checkup',
    collectionType: 'Home Collection',
    dateTime: '18 Oct 2026, 07:00 AM',
    address: 'Flat 402, Stellar Park, Sector 62, Noida',
    status: 'Phlebotomist Assigned',
    assignedLabId: 'lab-1',
    assignedPhlebotomist: 'Suresh Kumar (Phlebo ID: 44)',
    amount: 1499,
    summary: { normalCount: 0, abnormalCount: 0, status: 'Normal' }
  },
  {
    id: 'LB-9020',
    patientId: 'pat-102',
    patientName: 'Vikram Malhotra',
    patientPhone: '+91 98112 34567',
    testId: 'lt-3',
    testName: 'Thyroid Profile Total (T3, T4, TSH)',
    collectionType: 'Lab Visit',
    dateTime: '17 Oct 2026, 09:30 AM',
    address: 'HealthPilot Central Diagnostics, Sector 62, Noida',
    status: 'Report ready',
    assignedLabId: 'lab-1',
    amount: 399,
    reportUrl: 'Thyroid_Report_9020.pdf',
    summary: { normalCount: 3, abnormalCount: 0, status: 'Normal' }
  }
];

export const mockAppointments: DoctorAppointment[] = [
  {
    id: 'APT-501',
    patientId: 'pat-101',
    patientName: 'Priya Sharma',
    patientAge: 34,
    patientGender: 'Female',
    doctorId: 'doc-1',
    doctorName: 'Dr. Ananya Mukherjee',
    doctorSpecialty: 'General Physician',
    mode: 'Video',
    dateTime: 'Today, 05:00 PM',
    status: 'Scheduled',
    fee: 499,
    symptoms: 'Fever for 2 days with headache and mild throat irritation.'
  },
  {
    id: 'APT-500',
    patientId: 'pat-102',
    patientName: 'Vikram Malhotra',
    patientAge: 48,
    patientGender: 'Male',
    doctorId: 'doc-1',
    doctorName: 'Dr. Ananya Mukherjee',
    doctorSpecialty: 'General Physician',
    mode: 'Clinic visit',
    dateTime: '15 Oct 2026, 11:00 AM',
    status: 'Completed',
    fee: 499,
    prescription: {
      id: 'RX-9921',
      appointmentId: 'APT-500',
      patientName: 'Vikram Malhotra',
      doctorName: 'Dr. Ananya Mukherjee',
      doctorSpecialty: 'General Physician',
      doctorCouncilNo: 'DMC/R/18492',
      date: '15 Oct 2026',
      vitals: { bp: '130/84 mmHg', pulse: '76 bpm', weight: '74 kg', temp: '98.4 F' },
      diagnosis: 'Essential Hypertension Grade 1 & Hyperacidity',
      medicines: [
        { name: 'Telma 40mg Tablet', dosage: '1 Tablet Daily', duration: '30 Days', instructions: 'Take in the morning after breakfast' },
        { name: 'Pan-40 Tablet', dosage: '1 Tablet Daily', duration: '14 Days', instructions: 'Take empty stomach 30 mins before breakfast' }
      ],
      testsAdvised: ['Lipid Profile', 'Serum Creatinine', 'ECG (12 Lead)'],
      dietAdvice: 'Low sodium diet, reduce processed food, 30 min daily brisk walking.',
      signatureSvg: 'Dr. Ananya Mukherjee, MD'
    }
  }
];

export const mockPharmacyOrders: PharmacyOrder[] = [
  {
    id: 'ORD-7731',
    patientId: 'pat-101',
    patientName: 'Priya Sharma',
    patientPhone: '+91 98765 43210',
    pharmacyId: 'pharma-1',
    items: [
      { medicineId: 'med-1', medicineName: 'Glycomet-SR 500mg Tablet', quantity: 2, price: 95 },
      { medicineId: 'med-2', medicineName: 'Pan-40 Tablet', quantity: 1, price: 142 }
    ],
    totalAmount: 332,
    status: 'Out for delivery',
    orderDate: '17 Oct 2026',
    deliveryAddress: 'Flat 402, Stellar Park, Sector 62, Noida',
    rxAttached: true,
    rxImageUrl: 'Prescription_Dr_Mukherjee.jpg',
    deliveryPartner: 'Rahul Sharma (+91 98110 99887)'
  },
  {
    id: 'ORD-7732',
    patientId: 'pat-102',
    patientName: 'Vikram Malhotra',
    patientPhone: '+91 98112 34567',
    pharmacyId: 'pharma-1',
    items: [
      { medicineId: 'med-1', medicineName: 'Glycomet-SR 500mg Tablet', quantity: 3, price: 95 }
    ],
    totalAmount: 285,
    status: 'Placed',
    orderDate: '17 Oct 2026',
    deliveryAddress: 'A-12, Sector 15, Noida, UP',
    rxAttached: true,
    rxImageUrl: 'Prescription_Upload_Camera.jpg'
  }
];

export const mockHealthRecords: HealthRecord[] = [
  {
    id: 'REC-1',
    title: 'Consultation Prescription - Dr. Mukherjee',
    type: 'Prescription',
    date: '15 Oct 2026',
    doctorOrLab: 'Max Super Speciality Hospital',
    fileSize: '1.2 MB',
    url: '#'
  },
  {
    id: 'REC-2',
    title: 'Thyroid Panel Lab Report',
    type: 'Lab Report',
    date: '17 Oct 2026',
    doctorOrLab: 'HealthPilot Central Diagnostics',
    fileSize: '2.4 MB',
    url: '#'
  }
];

export const mockAdminRoles: AdminRoleConfig[] = [
  {
    roleId: 'role-sub-ops',
    roleName: 'Operations Sub-Admin',
    description: 'Manages user approvals, verification queues, and booking fulfillment.',
    permissions: [
      { module: 'Patients', view: true, create: true, edit: true, delete: false, export: true, approve: false },
      { module: 'Doctors', view: true, create: true, edit: true, delete: false, export: true, approve: true },
      { module: 'Pharmacists', view: true, create: true, edit: true, delete: false, export: true, approve: true },
      { module: 'Labs', view: true, create: true, edit: true, delete: false, export: true, approve: true },
      { module: 'Orders', view: true, create: true, edit: true, delete: false, export: true, approve: true },
      { module: 'Finance', view: true, create: false, edit: false, delete: false, export: true, approve: false }
    ]
  }
];

export const mockAuditLogs: AuditLog[] = [
  {
    id: 'LOG-1001',
    timestamp: '17 Oct 2026, 02:45 PM',
    adminName: 'Praveen Verma (Super Admin)',
    action: 'Approved Doctor Credential Verification',
    module: 'User & Role Management',
    ipAddress: '103.21.144.62 (Noida)',
    device: 'Chrome / macOS',
    details: 'Verified NMC registration DMC/R/18492 and approved Dr. Ananya Mukherjee.'
  },
  {
    id: 'LOG-1000',
    timestamp: '17 Oct 2026, 11:30 AM',
    adminName: 'Praveen Verma (Super Admin)',
    action: 'Approved Pharmacy Drug Licence',
    module: 'User & Role Management',
    ipAddress: '103.21.144.62 (Noida)',
    device: 'Chrome / macOS',
    details: 'Verified DL-UP-NOI-20B-99120 and approved Apollo Medicos & Healthcare Hub.'
  }
];

export const mockSupportTickets: SupportTicket[] = [
  {
    id: 'TKT-301',
    userName: 'Ramesh Sharma',
    category: 'Lab Booking',
    subject: 'Phlebotomist delayed for home sample collection',
    status: 'Open',
    priority: 'High',
    createdAt: 'Today, 06:30 AM'
  }
];
