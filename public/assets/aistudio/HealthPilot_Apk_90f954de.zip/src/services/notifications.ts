import { db, logFirestoreError, OperationType } from '../firebase';
import { collection, addDoc, setDoc, doc } from 'firebase/firestore';
import { AppNotification } from '../types';

export interface CreateNotificationParams {
  userId: string;
  title: string;
  body: string;
  type: AppNotification['type'];
  link?: string;
}

/**
 * Creates an in-app notification in Firestore.
 * Handles failures defensively so notification errors never block main user actions.
 */
export async function sendAppNotification(params: CreateNotificationParams): Promise<void> {
  if (!params.userId) return;

  try {
    const notifId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const notifRef = doc(db, 'notifications', notifId);

    await setDoc(notifRef, {
      id: notifId,
      userId: params.userId,
      title: params.title,
      body: params.body,
      type: params.type,
      read: false,
      createdAt: new Date().toISOString(),
      link: params.link || ''
    });

    // If user granted browser notification permission, show local browser alert
    showBrowserNotificationIfPermitted(params.title, params.body);

    /*
     * TODO: External Notification Gateways (SMS / WhatsApp / Email)
     * Real-world production channels require paid external providers:
     * - WhatsApp Cloud API / Gupshup / Twilio for automated WhatsApp alerts
     * - Fast2SMS / Twilio / AWS SNS for SMS OTP & booking alerts
     * - SendGrid / Resend / AWS SES for transactional email notifications
     * Integrations can be connected to Firebase Cloud Functions triggering on this 'notifications' collection.
     */
  } catch (err: any) {
    logFirestoreError(err, OperationType.CREATE, 'notifications');
  }
}

/**
 * Requests browser notification permission upon user interaction.
 */
export async function requestBrowserNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (e) {
    console.warn('Could not request notification permission:', e);
    return 'denied';
  }
}

/**
 * Shows browser notification if permitted.
 */
export function showBrowserNotificationIfPermitted(title: string, body: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/favicon.ico'
      });
    } catch (e) {
      // ignore
    }
  }
}
