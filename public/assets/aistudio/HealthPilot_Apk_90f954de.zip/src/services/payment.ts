/**
 * Payment Service Abstraction
 * Supports manual/cash payment methods (Pay at Clinic, Pay at Lab / Sample Collection, Cash on Delivery).
 * 
 * TODO: Add RazorpayProvider here when the gateway is ready
 */

export interface PaymentOrderInfo {
  id: string;
  type: 'consultation' | 'lab' | 'pharmacy';
  amount: number;
}

export interface PaymentResult {
  status: 'Pending' | 'Paid';
  referenceId: string;
  method: string;
}

export interface PaymentProvider {
  name: string;
  createPayment(order: PaymentOrderInfo, method: string): Promise<PaymentResult>;
}

export class ManualPaymentProvider implements PaymentProvider {
  name = 'Manual Payment';

  // Supported payment methods:
  // 'Pay at Clinic' | 'Pay at Lab / Sample Collection' | 'Cash on Delivery'
  async createPayment(order: PaymentOrderInfo, method: string): Promise<PaymentResult> {
    const referenceId = `HP-${order.type}-${order.id}`;
    return {
      status: 'Pending',
      referenceId,
      method
    };
  }
}

// TODO: Add RazorpayProvider here when the gateway is ready
export const PAYMENT_PROVIDER = 'manual';
export const manualPaymentService = new ManualPaymentProvider();
