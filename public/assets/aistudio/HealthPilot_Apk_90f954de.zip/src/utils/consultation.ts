/**
 * Helper utilities for Real Video Consultation via Jitsi Meet
 */

export function generateRoomName(appointmentId: string): string {
  const cleanId = (appointmentId || 'apt').toLowerCase().replace(/[^a-z0-9]/g, '');
  const randomChars = Math.random().toString(36).substring(2, 10);
  return `hp-${cleanId}-${randomChars}`;
}

/**
 * Checks if the consultation call window is active:
 * From 10 minutes before the appointment start until 60 minutes after.
 */
export function getCallWindowStatus(dateTimeStr: string): { canJoin: boolean; message?: string } {
  if (!dateTimeStr) {
    return { canJoin: true };
  }

  try {
    let apptTime = new Date(dateTimeStr).getTime();

    // If standard Date parsing fails on custom strings (e.g., "2026-10-25 10:30 AM")
    if (isNaN(apptTime)) {
      const match = dateTimeStr.match(/(\d{4}-\d{2}-\d{2})\s+(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
      if (match) {
        const [_, datePart, rawHour, minute, ampm] = match;
        let hour = parseInt(rawHour, 10);
        if (ampm) {
          if (ampm.toUpperCase() === 'PM' && hour < 12) hour += 12;
          if (ampm.toUpperCase() === 'AM' && hour === 12) hour = 0;
        }
        const parsed = new Date(`${datePart}T${hour.toString().padStart(2, '0')}:${minute}:00`);
        apptTime = parsed.getTime();
      }
    }

    // If still unparseable, allow join gracefully
    if (isNaN(apptTime)) {
      return { canJoin: true };
    }

    const now = Date.now();
    const tenMinutesBefore = apptTime - 10 * 60 * 1000;
    const sixtyMinutesAfter = apptTime + 60 * 60 * 1000;

    if (now < tenMinutesBefore) {
      return {
        canJoin: false,
        message: 'Call opens 10 minutes before your appointment time.'
      };
    }

    if (now > sixtyMinutesAfter) {
      return {
        canJoin: false,
        message: 'Consultation call window has expired (60 minutes past appointment start).'
      };
    }

    return { canJoin: true };
  } catch {
    return { canJoin: true };
  }
}

export function getJitsiUrl(roomName: string): string {
  const cleanRoom = encodeURIComponent(roomName || 'healthpilot-room');
  return `https://meet.jit.si/${cleanRoom}`;
}

export function getDirectionsUrl(address: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address || 'HealthPilot Clinic')}`;
}
