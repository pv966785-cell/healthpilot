import { DoctorProfile, WeekdaySchedule } from '../types';

export const DEFAULT_WEEKLY_SCHEDULE: WeekdaySchedule[] = [
  { day: 'Mon', enabled: true, startTime: '09:00', endTime: '17:00', slotDurationMinutes: 15 },
  { day: 'Tue', enabled: true, startTime: '09:00', endTime: '17:00', slotDurationMinutes: 15 },
  { day: 'Wed', enabled: true, startTime: '09:00', endTime: '17:00', slotDurationMinutes: 15 },
  { day: 'Thu', enabled: true, startTime: '09:00', endTime: '17:00', slotDurationMinutes: 15 },
  { day: 'Fri', enabled: true, startTime: '09:00', endTime: '17:00', slotDurationMinutes: 15 },
  { day: 'Sat', enabled: false, startTime: '10:00', endTime: '14:00', slotDurationMinutes: 15 },
  { day: 'Sun', enabled: false, startTime: '10:00', endTime: '14:00', slotDurationMinutes: 15 },
];

export interface ComputedSlot {
  time: string; // HH:mm
  slotId: string; // `${doctorId}_${YYYY-MM-DD}_${HHmm}`
  dateStr: string; // YYYY-MM-DD
  isPast: boolean;
  isBooked: boolean;
  label: string; // e.g. "9:00 AM"
}

export function formatDateToYYYYMMDD(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function formatTime12H(time24: string): string {
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr, 10);
  const m = mStr || '00';
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${m} ${ampm}`;
}

export function getDayName(date: Date): 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun' {
  const dayNames: ('Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat')[] = [
    'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'
  ];
  return dayNames[date.getDay()] as any;
}

export function generateDoctorSlots(
  doctor: DoctorProfile,
  targetDate: Date,
  bookedSlotIds: Set<string>
): ComputedSlot[] {
  const dateStr = formatDateToYYYYMMDD(targetDate);

  // Check if doctor marked this specific date unavailable
  if (doctor.schedule?.unavailableDates?.includes(dateStr)) {
    return [];
  }

  const dayName = getDayName(targetDate);
  const dayConfig = doctor.schedule?.weeklySchedule?.find(s => s.day === dayName) ?? 
    DEFAULT_WEEKLY_SCHEDULE.find(s => s.day === dayName) ?? {
      day: dayName,
      enabled: dayName !== 'Sun' && dayName !== 'Sat',
      startTime: '09:00',
      endTime: '17:00',
      slotDurationMinutes: 15
    };

  if (!dayConfig.enabled) {
    return [];
  }

  const [startH, startM] = (dayConfig.startTime || '09:00').split(':').map(Number);
  const [endH, endM] = (dayConfig.endTime || '17:00').split(':').map(Number);
  const step = dayConfig.slotDurationMinutes || 15;

  const startTotalMinutes = startH * 60 + startM;
  const endTotalMinutes = endH * 60 + endM;

  const now = new Date();
  const isToday = formatDateToYYYYMMDD(now) === dateStr;
  const currentTotalMinutes = now.getHours() * 60 + now.getMinutes();

  const slots: ComputedSlot[] = [];

  for (let m = startTotalMinutes; m + step <= endTotalMinutes; m += step) {
    const h = Math.floor(m / 60);
    const min = m % 60;
    const timeStr = `${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
    const cleanTime = timeStr.replace(':', '');
    const slotId = `${doctor.id}_${dateStr}_${cleanTime}`;

    // Past slot if today and slot start is in the past or within 5 minutes
    const isPast = isToday && (m <= currentTotalMinutes + 5);
    const isBooked = bookedSlotIds.has(slotId);

    slots.push({
      time: timeStr,
      slotId,
      dateStr,
      isPast,
      isBooked,
      label: formatTime12H(timeStr)
    });
  }

  return slots;
}

export function getNextAvailableSlot(
  doctor: DoctorProfile,
  bookedSlotIds: Set<string>
): string {
  if (doctor.isAvailableNow) {
    return 'Available Now';
  }

  const today = new Date();
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);

    const slots = generateDoctorSlots(doctor, d, bookedSlotIds);
    const firstOpen = slots.find(s => !s.isPast && !s.isBooked);

    if (firstOpen) {
      if (i === 0) return `Today, ${firstOpen.label}`;
      if (i === 1) return `Tomorrow, ${firstOpen.label}`;
      const dayStr = d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
      return `${dayStr}, ${firstOpen.label}`;
    }
  }

  return 'No slots this week';
}
