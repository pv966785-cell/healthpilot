import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';

/**
 * Uploads a file to Firebase Storage at the given path.
 * Validates file type (PDF, JPG, JPEG, PNG only) and size (max 5 MB).
 * 
 * @param path Storage destination path (e.g. `users/{uid}/degree.pdf`)
 * @param file File object from file input
 * @param onProgress Callback function receiving upload completion percentage (0-100)
 * @returns Download URL string
 */
export async function uploadFile(
  path: string,
  file: File,
  onProgress?: (progress: number) => void
): Promise<string> {
  if (!file) {
    throw new Error('No file provided for upload.');
  }

  // 1. Type validation (pdf, jpg, jpeg, png only)
  const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
  const ext = file.name.split('.').pop()?.toLowerCase();
  const isAllowedExt = ext && ['pdf', 'jpg', 'jpeg', 'png'].includes(ext);

  if (!allowedTypes.includes(file.type) && !isAllowedExt) {
    throw new Error('Only PDF, JPG or PNG allowed.');
  }

  // 2. Size validation (max 5 MB)
  const MAX_SIZE = 5 * 1024 * 1024; // 5 MB
  if (file.size > MAX_SIZE) {
    throw new Error('File too large. Max 5 MB.');
  }

  try {
    const storageRef = ref(storage, path);
    const contentType = file.type || (ext === 'pdf' ? 'application/pdf' : 'image/jpeg');
    const uploadTask = uploadBytesResumable(storageRef, file, { contentType });

    return new Promise<string>((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          if (snapshot.totalBytes > 0) {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            if (onProgress) onProgress(Math.round(progress));
          }
        },
        (error) => {
          console.error('Firebase Storage upload error:', error);
          if (error.code === 'storage/unauthorized') {
            reject(new Error('Permission denied. Please ensure you are logged in.'));
          } else if (error.code === 'storage/canceled') {
            reject(new Error('Upload was canceled.'));
          } else if (error.code === 'storage/bucket-not-found' || error.code === 'storage/project-not-found') {
            reject(new Error('Firebase Storage is not enabled in Firebase Console. Please follow STORAGE_SETUP.md.'));
          } else {
            reject(new Error('Upload failed: ' + (error.message || 'Storage error')));
          }
        },
        async () => {
          try {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadURL);
          } catch (err: any) {
            reject(new Error('Failed to retrieve file download URL. ' + (err?.message || '')));
          }
        }
      );
    });
  } catch (err: any) {
    console.error('Storage initialization error:', err);
    throw new Error(err?.message || 'Storage unavailable. Please check if Firebase Storage is enabled.');
  }
}
