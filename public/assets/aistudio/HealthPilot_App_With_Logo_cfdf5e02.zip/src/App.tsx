import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SplashScreen } from './components/SplashScreen';
import { WelcomeScreen } from './components/WelcomeScreen';
import { RoleSelectScreen } from './components/RoleSelectScreen';
import { AuthScreen } from './components/AuthScreen';
import { WaitingApprovalScreen } from './components/WaitingApprovalScreen';
import { PatientDashboard } from './components/patient/PatientDashboard';
import { DoctorDashboard } from './components/DoctorDashboard';
import { PharmacistDashboard } from './components/PharmacistDashboard';
import { LabDashboard } from './components/LabDashboard';
import { AdminPanel } from './components/AdminPanel';
import { LegalAndSupportModal, LegalTab } from './components/LegalAndSupportModal';
import { Sidebar } from './components/Sidebar';
import { AlertCircle } from 'lucide-react';

function AppContent() {
  const { 
    currentUser, isAuthenticated, isNewGoogleUser, logout, 
    resetInactivityTimer, currentRole 
  } = useAuth();

  const [unauthScreen, setUnauthScreen] = useState<'splash' | 'welcome' | 'role_select' | 'auth'>('splash');
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'admin'>('login');
  const [authRole, setAuthRole] = useState<any>('patient');

  const [isLargeFont, setIsLargeFont] = useState(false);
  const [language, setLanguage] = useState<'en' | 'hi'>('en');
  const [isDarkMode, setIsDarkMode] = useState(false);

  const [legalModal, setLegalModal] = useState<{ isOpen: boolean; tab: LegalTab }>({
    isOpen: false,
    tab: 'terms'
  });

  const openLegal = (tab: LegalTab) => setLegalModal({ isOpen: true, tab });
  const closeLegal = () => setLegalModal(prev => ({ ...prev, isOpen: false }));

  if (isNewGoogleUser) {
    return (
      <div className="relative">
        <AuthScreen initialMode="signup" initialRole="patient" onBack={() => {}} language={language} isDarkMode={isDarkMode} onToggleLanguage={() => setLanguage(l => l === 'en' ? 'hi' : 'en')} onOpenLegal={openLegal} />
        <LegalAndSupportModal isOpen={legalModal.isOpen} initialTab={legalModal.tab} onClose={closeLegal} isDarkMode={isDarkMode} />
      </div>
    );
  }

  if (!isAuthenticated || !currentUser) {
    if (unauthScreen === 'splash') return <SplashScreen onProceed={() => setUnauthScreen('welcome')} />;
    if (unauthScreen === 'role_select') {
      return (
        <div className="relative">
          <RoleSelectScreen
            onSelectRole={(role) => {
              if (role === 'super_admin' || role === 'sub_admin') { setAuthRole('super_admin'); setAuthMode('admin'); }
              else { setAuthRole(role); setAuthMode('login'); }
              setUnauthScreen('auth');
            }}
            onBack={() => setUnauthScreen('welcome')}
            language={language}
            isDarkMode={isDarkMode}
            onToggleLanguage={() => setLanguage(l => l === 'en' ? 'hi' : 'en')}
          />
          <LegalAndSupportModal isOpen={legalModal.isOpen} initialTab={legalModal.tab} onClose={closeLegal} isDarkMode={isDarkMode} />
        </div>
      );
    }
    if (unauthScreen === 'auth') {
      return (
        <div className="relative">
          <AuthScreen
            initialMode={authMode}
            initialRole={authRole}
            onBack={() => authMode === 'signup' ? setUnauthScreen('welcome') : setUnauthScreen('role_select')}
            language={language}
            isDarkMode={isDarkMode}
            onToggleLanguage={() => setLanguage(l => l === 'en' ? 'hi' : 'en')}
            onOpenLegal={openLegal}
          />
          <LegalAndSupportModal isOpen={legalModal.isOpen} initialTab={legalModal.tab} onClose={closeLegal} isDarkMode={isDarkMode} />
        </div>
      );
    }
    return (
      <div className="relative">
        <WelcomeScreen
          onGoToLogin={() => setUnauthScreen('role_select')}
          onGoToSignUp={() => { setAuthRole('patient'); setAuthMode('signup'); setUnauthScreen('auth'); }}
          language={language}
          isDarkMode={isDarkMode}
          onToggleLanguage={() => setLanguage(l => l === 'en' ? 'hi' : 'en')}
          onToggleDarkMode={() => setIsDarkMode(d => !d)}
          onOpenLegal={openLegal}
        />
        <LegalAndSupportModal isOpen={legalModal.isOpen} initialTab={legalModal.tab} onClose={closeLegal} isDarkMode={isDarkMode} />
      </div>
    );
  }

  if (currentUser.status === 'Pending') return <WaitingApprovalScreen />;
  if (currentUser.status === 'Suspended' || currentUser.status === 'Blocked') {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
        <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
        <h2 className="text-2xl font-extrabold mb-2">Account {currentUser.status}</h2>
        <button onClick={logout} className="px-5 py-2.5 bg-slate-800 rounded-xl text-xs font-bold hover:bg-slate-700">Logout</button>
      </div>
    );
  }

  return (
    <div className={`min-h-[100dvh] flex ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} font-sans`}>
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <Routes>
          <Route path="/dashboard/*" element={
            currentUser.role === 'patient' ? <PatientDashboard /> :
              currentUser.role === 'doctor' ? <DoctorDashboard /> :
              currentUser.role === 'pharmacist' ? <PharmacistDashboard /> :
              currentUser.role === 'lab' ? <LabDashboard /> :
              <AdminPanel />
          } />
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </main>
      <LegalAndSupportModal isOpen={legalModal.isOpen} initialTab={legalModal.tab} onClose={closeLegal} isDarkMode={isDarkMode} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AuthProvider>
  );
}
