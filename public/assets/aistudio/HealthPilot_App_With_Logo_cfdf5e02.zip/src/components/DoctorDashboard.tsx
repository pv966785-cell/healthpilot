import React, { useState } from 'react';
import { useAuth, sanitizeFirestoreDoc } from '../context/AuthContext';
import { HealthPilotLogo } from './HealthPilotLogo';
import { DoctorProfile, DoctorAppointment, DigitalPrescription } from '../types';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { 
  Video, MessageSquare, Clock, CheckCircle2, FileText, User, 
  Calendar, CreditCard, Star, Plus, ShieldCheck, LogOut, ArrowRight, X, Download, AlertCircle, Loader2 
} from 'lucide-react';

export const DoctorDashboard: React.FC = () => {
  const { currentUser, logout, appointments, dataLoading, updateAppointment } = useAuth();
  const doctor = currentUser as DoctorProfile;

  const [isAvailable, setIsAvailable] = useState<boolean>(true);
  const [activeCallAppointment, setActiveCallAppointment] = useState<DoctorAppointment | null>(null);
  const [showRxModal, setShowRxModal] = useState<DoctorAppointment | null>(null);
  const [isSubmittingRx, setIsSubmittingRx] = useState<boolean>(false);

  const [rxDiagnosis, setRxDiagnosis] = useState('Viral Upper Respiratory Tract Infection & Fatigue');
  const [rxMedicines, setRxMedicines] = useState([
    { name: 'Pan-40 Tablet', dosage: '1 Tab Daily', duration: '5 Days', instructions: 'Before breakfast' },
    { name: 'Azithral 500mg', dosage: '1 Tab Daily', duration: '3 Days', instructions: 'After lunch' }
  ]);
  const [rxTests, setRxTests] = useState('CBC with ESR');
  const [rxAdvice, setRxAdvice] = useState('Drink warm fluids, steam inhalation twice daily, complete rest.');

  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const showToast = (msg: string, isError = false) => {
    setToastMessage({ text: msg, isError });
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSavePrescription = async () => {
    if (!showRxModal || isSubmittingRx) return;
    setIsSubmittingRx(true);
    const newRx: DigitalPrescription = {
      id: `RX-${Date.now().toString().slice(-4)}`,
      appointmentId: showRxModal.id,
      patientName: showRxModal.patientName,
      doctorName: doctor?.name || 'Dr. Consultant',
      doctorSpecialty: doctor?.specialty || 'General Physician',
      doctorCouncilNo: doctor?.councilRegistrationNumber || '',
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      vitals: { bp: '120/80 mmHg', pulse: '74 bpm', weight: '65 kg', temp: '98.6 F' },
      diagnosis: rxDiagnosis,
      medicines: rxMedicines,
      testsAdvised: [rxTests],
      dietAdvice: rxAdvice,
      signatureSvg: doctor?.name || 'Dr. Verified'
    };

    try {
      await updateAppointment(showRxModal.id, { status: 'Completed', prescription: newRx });
      
      // Auto-create health record in Firestore for the patient
      try {
        const recordId = `HR-${Date.now().toString().slice(-6)}`;
        await setDoc(doc(db, 'healthRecords', recordId), sanitizeFirestoreDoc({
          id: recordId,
          patientId: showRxModal.patientId,
          title: `Prescription: ${newRx.diagnosis}`,
          type: 'Prescription',
          date: newRx.date,
          doctorOrLab: doctor.name,
          url: `Prescription_${showRxModal.id}.pdf`,
          createdAt: new Date().toISOString()
        }));
      } catch (recErr) {
        console.warn('Health record auto-save note:', recErr);
      }

      showToast('Digital Prescription generated with official HealthPilot stamp!');
      setShowRxModal(null);
    } catch (err: any) {
      showToast(err?.message || 'Failed to save digital prescription.', true);
    } finally {
      setIsSubmittingRx(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F1F7FF] dark:bg-slate-950 p-6 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-6 right-6 z-50 ${toastMessage.isError ? 'bg-red-600' : 'bg-[#0FB5A0]'} text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 border`}>
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-semibold">{toastMessage.text}</span>
        </div>
      )}

      {/* Doctor Dashboard Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">Dr. {doctor.name}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Welcome back to your clinical dashboard</p>
        </div>
        <div className="flex items-center gap-4">
          <div className={`flex items-center gap-2 px-4 py-2 rounded-2xl border ${isAvailable ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-slate-100 border-slate-200 text-slate-600'}`}>
            <span className={`w-2 h-2 rounded-full ${isAvailable ? 'bg-emerald-500' : 'bg-slate-400'}`} />
            <span className="text-xs font-bold">{isAvailable ? 'Available for Consults' : 'Offline'}</span>
            <button onClick={() => setIsAvailable(!isAvailable)} className="ml-2 underline text-[10px]">Toggle</button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
          <p className="text-xs font-bold text-slate-400 uppercase">Today's Patients</p>
          <p className="text-3xl font-extrabold text-[#1769E0] mt-1">{appointments.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
          <p className="text-xs font-bold text-slate-400 uppercase">Pending Prescriptions</p>
          <p className="text-3xl font-extrabold text-teal-600 mt-1">{appointments.filter(a => a.status !== 'Completed').length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
          <p className="text-xs font-bold text-slate-400 uppercase">Average Rating</p>
          <p className="text-3xl font-extrabold text-amber-500 mt-1">{doctor.rating || 0}</p>
        </div>
      </div>

      {/* Appointments List */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-lg font-extrabold">Consultations Queue</h3>
        </div>
        {dataLoading ? (
          <div className="p-12 text-center text-slate-400">Loading your schedule...</div>
        ) : appointments.length === 0 ? (
          <div className="p-12 text-center text-slate-500">No appointments scheduled for today.</div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {appointments.map(apt => (
              <div key={apt.id} className="p-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-100 text-[#1769E0] flex items-center justify-center font-bold text-lg">
                    {apt.patientName.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-sm text-slate-900 dark:text-white">{apt.patientName}</p>
                    <p className="text-xs text-slate-500">{apt.dateTime} • {apt.mode}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setActiveCallAppointment(apt)} className="px-4 py-2 bg-[#1769E0] text-white rounded-xl text-xs font-bold hover:bg-blue-700">Call</button>
                  <button onClick={() => setShowRxModal(apt)} className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold hover:bg-teal-700">Prescription</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
