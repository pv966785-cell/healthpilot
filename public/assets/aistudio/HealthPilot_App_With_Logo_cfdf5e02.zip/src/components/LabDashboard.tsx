import React, { useState } from 'react';
import { useAuth, sanitizeFirestoreDoc } from '../context/AuthContext';
import { HealthPilotLogo } from './HealthPilotLogo';
import { LabProfile, LabBooking } from '../types';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { 
  Activity, CheckCircle2, Clock, Upload, User, 
  MapPin, LogOut, ArrowRight, ShieldCheck, FileText, Check, AlertCircle, Loader2, FlaskConical 
} from 'lucide-react';

export const LabDashboard: React.FC = () => {
  const { 
    currentUser, logout, labBookings, dataLoading, updateLabBooking, 
    labTests, updateLabTest, deleteLabTest
  } = useAuth();
  const lab = currentUser as LabProfile;
  const bookings = labBookings;

  const [selectedBookingForReport, setSelectedBookingForReport] = useState<LabBooking | null>(null);
  const [phleboName, setPhleboName] = useState('Ramesh Yadav (Phlebo #12)');
  const [reportFileName, setReportFileName] = useState('CBC_Thyroid_NABL_Report.pdf');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const showToast = (msg: string, isError = false) => {
    setToastMessage({ text: msg, isError });
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleUpdateStatus = async (bookingId: string, nextStatus: LabBooking['status']) => {
    if (isProcessing) return;
    setIsProcessing(true);
    try {
      await updateLabBooking(bookingId, { status: nextStatus });
      showToast(`Booking ${bookingId} status updated to: ${nextStatus.toUpperCase()}`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to update booking status.', true);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAssignPhlebotomist = async (bookingId: string) => {
    if (isProcessing) return;
    setIsProcessing(true);
    try {
      await updateLabBooking(bookingId, { assignedPhlebotomist: phleboName, status: 'Phlebotomist Assigned' });
      showToast(`Assigned ${phleboName} for sample collection.`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to assign phlebotomist.', true);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUploadReport = async () => {
    if (!selectedBookingForReport || isProcessing) return;
    setIsProcessing(true);
    try {
      await updateLabBooking(selectedBookingForReport.id, { 
        status: 'Report ready', 
        reportUrl: reportFileName,
        summary: { normalCount: 12, abnormalCount: 0, status: 'Normal' }
      });

      // Auto-save health record in Firestore for patient vault
      try {
        const recordId = `HR-${Date.now().toString().slice(-6)}`;
        await setDoc(doc(db, 'healthRecords', recordId), sanitizeFirestoreDoc({
          id: recordId,
          patientId: selectedBookingForReport.patientId,
          title: `${selectedBookingForReport.testName} (Lab Report)`,
          type: 'Lab Report',
          date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
          doctorOrLab: lab.labName || lab.name || 'Diagnostic Centre',
          url: reportFileName,
          createdAt: new Date().toISOString()
        }));
      } catch (hrErr) {
        console.warn('Health record auto-save error:', hrErr);
      }

      setSelectedBookingForReport(null);
      showToast(`Official NABL Report uploaded and patient notified.`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to upload report.', true);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F1F7FF] dark:bg-slate-950 p-6 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-6 right-6 z-50 ${toastMessage.isError ? 'bg-red-600' : 'bg-[#8B5CF6]'} text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 border`}>
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-semibold">{toastMessage.text}</span>
        </div>
      )}

      {/* Lab Dashboard Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">{lab.labName || 'Diagnostic Centre'}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{lab.accreditation || 'NABL'} Accredited • {lab.labAddress}</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm text-center">
            <p className="text-[10px] font-bold text-slate-400 uppercase">Active Bookings</p>
            <p className="text-lg font-extrabold text-[#8B5CF6]">{bookings.length}</p>
          </div>
        </div>
      </div>

      {/* Bookings Queue */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-lg font-extrabold">Live Diagnostic Pipeline</h3>
        </div>
        {dataLoading ? (
          <div className="p-12 text-center text-slate-400">Loading bookings...</div>
        ) : bookings.length === 0 ? (
          <div className="p-12 text-center text-slate-500">No active bookings.</div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {bookings.map(booking => (
              <div key={booking.id} className="p-6 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <p className="font-bold text-sm">{booking.testName}</p>
                    <p className="text-xs text-slate-500">{booking.patientName} • {booking.dateTime}</p>
                  </div>
                  <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700">{booking.status}</span>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleAssignPhlebotomist(booking.id)} className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold">Assign Phlebo</button>
                  <button onClick={() => setSelectedBookingForReport(booking)} className="px-4 py-2 bg-[#8B5CF6] text-white rounded-xl text-xs font-bold">Upload Report</button>
                  <button onClick={() => handleUpdateStatus(booking.id, 'Processing')} className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold">Process</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
