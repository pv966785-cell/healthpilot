import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, Calendar, FileText, ShoppingBag, User, Phone, MapPin, 
  ShieldAlert, Clock, CheckCircle2, ChevronRight, Upload, Video, 
  MessageSquare, Stethoscope, Activity, CreditCard, Bell, HelpCircle, 
  Globe, AlertTriangle, X, Plus, Star, ArrowLeft, Download, Send, Check,
  Heart, ShieldCheck, Truck, Zap, Trash2, Edit3, Loader2,
  ChevronDown, ChevronUp, ArrowUpDown, Filter, Sparkles, Info
} from 'lucide-react';
import { founderDetails } from '../mockData';
import { mockMedicines } from '../data/catalog';
import { formatINR, LAB_TEST_CATEGORIES } from '../content';
import { LabTest, Doctor, Medicine, FamilyMember, DoctorAppointment, LabBooking, PharmacyOrder, PatientProfile, HealthRecord } from '../types';
import { HealthPilotLogo } from './HealthPilotLogo';
import { FounderAvatar } from './FounderAvatar';
import { PharmacyOrderTracker } from './PharmacyOrderTracker';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';

interface PatientAppProps {
  isLargeFont: boolean;
  language: 'en' | 'hi';
  isDarkMode: boolean;
  onToggleLanguage: () => void;
  onToggleFont: () => void;
  onToggleDarkMode: () => void;
  onOpenLegal?: (tab: 'terms' | 'privacy' | 'contact') => void;
}

function parseAppointmentTimestamp(dateTimeStr: string): number {
  const now = Date.now();
  if (!dateTimeStr) return now + (3 * 3600 + 42 * 60 + 15) * 1000;

  const direct = Date.parse(dateTimeStr);
  if (!isNaN(direct) && direct > now) {
    return direct;
  }

  const isTomorrow = /tomorrow/i.test(dateTimeStr);
  const timeMatch = dateTimeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);

  if (timeMatch) {
    let hours = parseInt(timeMatch[1], 10);
    const minutes = parseInt(timeMatch[2], 10);
    const ampm = timeMatch[3]?.toUpperCase();
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;

    const target = new Date();
    if (isTomorrow) target.setDate(target.getDate() + 1);
    target.setHours(hours, minutes, 0, 0);

    if (target.getTime() > now) {
      return target.getTime();
    }
  }

  return now + (3 * 3600 + 42 * 60 + 15) * 1000;
}

const AppointmentReminderCard: React.FC<{
  appointment: DoctorAppointment;
  onJoin: () => void;
  onReschedule: () => void;
}> = ({ appointment, onJoin, onReschedule }) => {
  const [timeLeft, setTimeLeft] = useState<{
    hours: number;
    minutes: number;
    seconds: number;
    isExpired: boolean;
  }>({
    hours: 3,
    minutes: 42,
    seconds: 15,
    isExpired: false
  });

  const targetTimeRef = useRef<number>(0);

  useEffect(() => {
    targetTimeRef.current = parseAppointmentTimestamp(appointment.dateTime);

    const tick = () => {
      const diff = targetTimeRef.current - Date.now();
      if (diff <= 0) {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0, isExpired: true });
        return;
      }
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setTimeLeft({ hours, minutes, seconds, isExpired: false });
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [appointment.dateTime]);

  const pad = (n: number) => String(n).padStart(2, '0');

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 p-4 text-slate-950 shadow-xl shadow-amber-500/25 border-2 border-amber-300">
      <div className="absolute -right-6 -bottom-6 w-28 h-28 rounded-full bg-white/20 pointer-events-none blur-sm" />
      <div className="absolute right-3 top-3 text-slate-900/30 pointer-events-none">
        <Bell className="w-10 h-10" />
      </div>

      <div className="relative z-10 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-1.5 bg-slate-950/20 backdrop-blur-md px-3 py-1 rounded-full text-slate-950 font-extrabold text-[10px] tracking-wider uppercase border border-slate-950/10">
            <span className="w-2 h-2 rounded-full bg-slate-950 animate-ping inline-block" />
            <Bell className="w-3 h-3 text-slate-950" />
            <span>Reminder • Appointment in &lt;24h</span>
          </div>
          <span className="text-[10px] font-bold text-slate-950 bg-white/40 px-2.5 py-0.5 rounded-full">
            {appointment.mode}
          </span>
        </div>

        <div>
          <h3 className="font-extrabold text-base text-slate-950 leading-tight">
            {appointment.doctorName}
          </h3>
          <p className="text-xs font-semibold text-slate-900/90 mt-0.5">
            {appointment.doctorSpecialty} • {appointment.dateTime}
          </p>
        </div>

        {/* Live Countdown Box */}
        <div className="bg-slate-950/90 text-white p-3 rounded-2xl flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[9px] uppercase tracking-wider text-amber-300 font-extrabold block">
                Live Countdown
              </span>
              <span className="text-xs font-mono font-bold text-slate-200">
                {timeLeft.isExpired
                  ? 'Starting Now'
                  : `Starts in ${pad(timeLeft.hours)}h : ${pad(timeLeft.minutes)}m : ${pad(timeLeft.seconds)}s`}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 font-mono text-xs font-extrabold text-amber-400 bg-amber-500/10 px-2 py-1 rounded-lg border border-amber-500/20">
            <span>{pad(timeLeft.hours)}</span>:<span>{pad(timeLeft.minutes)}</span>:<span>{pad(timeLeft.seconds)}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-0.5">
          <button
            onClick={onJoin}
            className="flex-1 py-2.5 bg-slate-950 hover:bg-slate-900 text-white rounded-xl text-xs font-extrabold shadow-md flex items-center justify-center gap-1.5 transition-transform active:scale-95"
          >
            <Video className="w-3.5 h-3.5 text-emerald-400" />
            <span>Join Call</span>
          </button>
          <button
            onClick={onReschedule}
            className="flex-1 py-2.5 bg-white/95 hover:bg-white text-slate-950 rounded-xl text-xs font-extrabold shadow-md flex items-center justify-center gap-1.5 border border-amber-300 transition-transform active:scale-95"
          >
            <Calendar className="w-3.5 h-3.5 text-blue-600" />
            <span>Reschedule</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export const PatientApp: React.FC<PatientAppProps> = ({ 
  isLargeFont, language, isDarkMode, onToggleLanguage, onToggleFont, onToggleDarkMode, onOpenLegal 
}) => {
  const { 
    currentUser, doctors, pharmacists, labs, appointments, labBookings, pharmacyOrders, 
    createAppointment, updateAppointment, createLabBooking, createPharmacyOrder,
    updateFamilyMembers, updatePatientProfile, dataLoading,
    labTests, getPatientPrice
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'home' | 'consultation' | 'tests' | 'medicines' | 'profile'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('All');
  const [selectedMedCategory, setSelectedMedCategory] = useState<string>('All');

  // Lab Tests State (Search, Category Filter, Sort, Expansion, Pagination)
  const [testSearchQuery, setTestSearchQuery] = useState('');
  const [selectedTestCategory, setSelectedTestCategory] = useState<string>('All');
  const [testSortBy, setTestSortBy] = useState<'default' | 'price_asc' | 'price_desc' | 'name_asc'>('default');
  const [expandedPanelIds, setExpandedPanelIds] = useState<Set<string>>(new Set());
  const [testsVisibleCount, setTestsVisibleCount] = useState<number>(20);

  const togglePanelExpand = (testId: string) => {
    setExpandedPanelIds(prev => {
      const next = new Set(prev);
      if (next.has(testId)) next.delete(testId);
      else next.add(testId);
      return next;
    });
  };

  // Modals & Flows
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [selectedTestForBooking, setSelectedTestForBooking] = useState<LabTest | null>(null);
  const [selectedDoctorForBooking, setSelectedDoctorForBooking] = useState<Doctor | null>(null);
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [cartMedicines, setCartMedicines] = useState<{ medicine: Medicine; quantity: number }[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [activeConsultationRoom, setActiveConsultationRoom] = useState<Doctor | null>(null);
  const [showReportViewer, setShowReportViewer] = useState(false);
  const [rescheduleAppt, setRescheduleAppt] = useState<DoctorAppointment | null>(null);
  const [rescheduleSlot, setRescheduleSlot] = useState<string>('Tomorrow, 10:00 AM');
  const [rescheduleReason, setRescheduleReason] = useState<string>('Schedule conflict');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active provider lists from context
  const activePharmacists = pharmacists.filter(p => p.status === 'Active');
  const activeLabs = labs.filter(l => l.status === 'Active');
  const activeDoctors = doctors.filter(d => d.status === 'Active');

  // Provider assignment states
  const [selectedLabId, setSelectedLabId] = useState<string>('');
  const [selectedPharmacyId, setSelectedPharmacyId] = useState<string>('');

  // Auto-set first active provider whenever lists change
  useEffect(() => {
    if (activeLabs.length > 0 && !selectedLabId) {
      setSelectedLabId(activeLabs[0].id);
    }
  }, [activeLabs, selectedLabId]);

  useEffect(() => {
    if (activePharmacists.length > 0 && !selectedPharmacyId) {
      setSelectedPharmacyId(activePharmacists[0].id);
    }
  }, [activePharmacists, selectedPharmacyId]);

  // Request in-progress submission locks to prevent double-booking
  const [isBookingDoctor, setIsBookingDoctor] = useState(false);
  const [isBookingLab, setIsBookingLab] = useState(false);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [isUploadingRx, setIsUploadingRx] = useState(false);

  // Profile Edit Modal & Completeness state
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [editPhone, setEditPhone] = useState(currentUser?.phone || '');
  const [editAddress, setEditAddress] = useState((currentUser as PatientProfile)?.address || '');
  const [editAge, setEditAge] = useState(String((currentUser as PatientProfile)?.age || ''));
  const [editBloodGroup, setEditBloodGroup] = useState((currentUser as PatientProfile)?.bloodGroup || 'O+');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setEditPhone(currentUser.phone || '');
      setEditAddress((currentUser as PatientProfile)?.address || '');
      setEditAge(String((currentUser as PatientProfile)?.age || ''));
      setEditBloodGroup((currentUser as PatientProfile)?.bloodGroup || 'O+');
    }
  }, [currentUser]);

  const isProfileComplete = Boolean(
    currentUser?.phone?.trim() && 
    (currentUser as PatientProfile)?.address?.trim()
  );

  // Family Members vault modal state
  const [showAddFamilyModal, setShowAddFamilyModal] = useState(false);
  const [newFmName, setNewFmName] = useState('');
  const [newFmRelation, setNewFmRelation] = useState<'Father' | 'Mother' | 'Spouse' | 'Son' | 'Daughter' | 'Self'>('Spouse');
  const [newFmAge, setNewFmAge] = useState('');
  const [newFmGender, setNewFmGender] = useState<'Male' | 'Female' | 'Other'>('Female');
  const [newFmBlood, setNewFmBlood] = useState('O+');
  const [isSavingFamily, setIsSavingFamily] = useState(false);

  const familyMembers: FamilyMember[] = (currentUser as PatientProfile)?.familyMembers || [];

  // Real Health Records subscription from Firestore
  const [healthRecords, setHealthRecords] = useState<HealthRecord[]>([]);
  const [healthRecordsLoading, setHealthRecordsLoading] = useState(true);

  useEffect(() => {
    if (!currentUser?.id) {
      setHealthRecords([]);
      setHealthRecordsLoading(false);
      return;
    }
    const q = query(
      collection(db, 'healthRecords'),
      where('patientId', '==', currentUser.id)
    );
    const unsub = onSnapshot(q, (snapshot) => {
      const records: HealthRecord[] = [];
      snapshot.forEach(docSnap => {
        const d = docSnap.data();
        records.push({
          id: docSnap.id,
          title: d.title || 'Medical Record',
          type: d.type || 'Prescription',
          date: d.date || '',
          doctorOrLab: d.doctorOrLab || 'HealthPilot Care',
          fileSize: d.fileSize || '1.2 MB',
          url: d.url || '#'
        });
      });
      records.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setHealthRecords(records);
      setHealthRecordsLoading(false);
    }, (err) => {
      console.warn('Health records snapshot error:', err);
      setHealthRecordsLoading(false);
    });
    return () => unsub();
  }, [currentUser?.id]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleAddToCart = (med: Medicine) => {
    setCartMedicines(prev => {
      const existing = prev.find(item => item.medicine.id === med.id);
      if (existing) {
        return prev.map(item => item.medicine.id === med.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { medicine: med, quantity: 1 }];
    });
    showToast(`Added ${med.name} to cart`);
  };

  // Real Active Doctors from Firestore (no mockDoctors fallback)
  const allAvailableDoctors: Doctor[] = activeDoctors.map(d => ({
    id: d.id,
    name: d.name,
    specialty: d.specialty || 'General Physician',
    qualification: d.qualification || 'MBBS',
    experienceYears: d.experienceYears || 1,
    hospital: d.hospitalOrClinic || 'HealthPilot Partner Clinic',
    rating: d.rating || 5.0,
    reviewCount: d.reviewCount || 0,
    consultationFee: d.consultationFee || 500,
    languages: d.languages || ['English', 'Hindi'],
    nextAvailableSlot: d.isAvailableNow ? 'Available Now' : 'Today, 4:00 PM',
    avatarUrl: d.avatarUrl || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&auto=format&fit=crop&q=80',
    bio: d.bio || 'Consultant Physician.'
  }));

  const filteredDoctors = selectedSpecialty === 'All' 
    ? allAvailableDoctors 
    : allAvailableDoctors.filter(d => d.specialty === selectedSpecialty);

  const filteredMedicines = selectedMedCategory === 'All'
    ? mockMedicines
    : mockMedicines.filter(m => m.category === selectedMedCategory);

  // Active tests filtered for patient display (inactive tests hidden)
  const activeCatalogueTests = labTests.filter(t => t.active !== false);

  // Homepage Special Panels preview (First 4 Special Panels: Akshaya Health Check-ups)
  const specialPanelsPreview = activeCatalogueTests
    .filter(t => t.category === 'Special Panels')
    .slice(0, 4);

  // Lab Tests tab filtered and sorted list
  const filteredLabTests = activeCatalogueTests.filter(t => {
    const matchesCategory = selectedTestCategory === 'All' || t.category === selectedTestCategory;
    if (!matchesCategory) return false;
    if (!testSearchQuery.trim()) return true;
    const q = testSearchQuery.toLowerCase();
    const matchesName = t.name.toLowerCase().includes(q);
    const matchesCategoryName = t.category.toLowerCase().includes(q);
    const matchesSample = (t.sampleType || '').toLowerCase().includes(q);
    const matchesIncludes = t.includes ? t.includes.some(inc => inc.toLowerCase().includes(q)) : false;
    return matchesName || matchesCategoryName || matchesSample || matchesIncludes;
  }).sort((a, b) => {
    if (testSortBy === 'price_asc') {
      return getPatientPrice(a.labRate) - getPatientPrice(b.labRate);
    }
    if (testSortBy === 'price_desc') {
      return getPatientPrice(b.labRate) - getPatientPrice(a.labRate);
    }
    if (testSortBy === 'name_asc') {
      return a.name.localeCompare(b.name);
    }
    return 0;
  });

  const visibleLabTests = filteredLabTests.slice(0, testsVisibleCount);

  return (
    <div className={`w-full md:max-w-[480px] md:mx-auto min-h-[100dvh] h-[100dvh] ${isDarkMode ? 'mesh-bg-dark text-slate-100' : 'mesh-bg-light text-slate-900'} flex flex-col relative font-sans overflow-hidden ${isLargeFont ? 'text-lg' : 'text-base'} shadow-2xl`}>
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed md:absolute top-16 left-4 right-4 z-50 bg-[#0B2A6F] text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-bounce border border-teal-400">
          <CheckCircle2 className="w-5 h-5 text-teal-400 shrink-0" />
          <span className="text-sm font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Emergency SOS Modal */}
      {showEmergencyModal && (
        <div className="absolute inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-md">
          <div className={`${isDarkMode ? 'bg-slate-900 text-white border-red-500/80' : 'bg-white text-slate-900 border-red-500'} w-full rounded-[32px] p-6 shadow-2xl border-2 text-center`}>
            <div className="w-16 h-16 bg-red-500/15 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-500/30">
              <ShieldAlert className="w-8 h-8 text-red-600 animate-pulse" />
            </div>
            <h3 className="text-2xl font-extrabold mb-2 tracking-tight">Emergency Medical SOS</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
              Instant dispatch to nearest hospital ambulance & emergency response team in Noida / NCR.
            </p>
            <div className="space-y-3">
              <a 
                href="tel:108" 
                className="w-full py-4 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white rounded-2xl font-extrabold text-base flex items-center justify-center gap-3 shadow-lg shadow-red-500/25 transition-all"
              >
                <Phone className="w-5 h-5" /> Call Ambulance (108 / 112)
              </a>
              <button 
                onClick={() => {
                  setShowEmergencyModal(false);
                  showToast('SOS Alert dispatched with your live GPS location to family!');
                }}
                className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                Send SOS SMS to Family
              </button>
              <button 
                onClick={() => setShowEmergencyModal(false)}
                className="w-full py-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-2xl font-semibold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Mobile Header */}
      <header className={`glass-header px-4 py-3 flex items-center justify-between shrink-0 sticky top-0 z-20 pt-[max(0.75rem,env(safe-area-inset-top,0px))]`}>
        <div className="flex items-center gap-2">
          <HealthPilotLogo size="sm" />
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={onToggleLanguage}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1 shadow-xs ${
              isDarkMode ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white/80 border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-[#1769E0]" /> {language === 'en' ? '🇮🇳 हिंदी' : 'English'}
          </button>
          <button 
            onClick={onToggleDarkMode}
            className={`p-1.5 rounded-xl text-xs font-bold border transition-colors shadow-xs ${
              isDarkMode ? 'bg-slate-800/80 border-slate-700 text-amber-300 hover:bg-slate-700' : 'bg-white/80 border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {isDarkMode ? '🌙' : '☀️'}
          </button>
          <button 
            onClick={() => setShowEmergencyModal(true)}
            className="px-3 py-1.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1 shadow-md shadow-red-500/25 animate-pulse"
          >
            <ShieldAlert className="w-3.5 h-3.5" /> SOS
          </button>
        </div>
      </header>

      {/* Scrollable View Area */}
      <main className="flex-1 overflow-y-auto pb-24">
        
        {/* 1. HOME TAB */}
        {activeTab === 'home' && (
          <div className="p-4 space-y-4">
            
            {/* Push-Notification Style Appointment Reminder Card for next 24 hours */}
            {(() => {
              const now = Date.now();
              const upcomingAppt = appointments.find(ap => {
                if (ap.status !== 'Scheduled') return false;
                const apptTime = parseAppointmentTimestamp(ap.dateTime);
                const diff = apptTime - now;
                return diff > 0 && diff <= 24 * 3600 * 1000;
              });

              if (!upcomingAppt) return null;

              return (
                <AppointmentReminderCard
                  appointment={upcomingAppt}
                  onJoin={() => {
                    setActiveConsultationRoom({
                      id: upcomingAppt.doctorId,
                      name: upcomingAppt.doctorName,
                      specialty: upcomingAppt.doctorSpecialty,
                      qualification: 'MBBS, MD',
                      experienceYears: 10,
                      hospital: 'HealthPilot Clinic',
                      rating: 4.9,
                      reviewCount: 100,
                      consultationFee: upcomingAppt.fee,
                      languages: ['English', 'Hindi'],
                      nextAvailableSlot: upcomingAppt.dateTime,
                      avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300',
                      bio: 'Consultant Physician'
                    });
                  }}
                  onReschedule={() => {
                    setRescheduleAppt(upcomingAppt);
                  }}
                />
              );
            })()}

            {/* Greeting & Slogan */}
            <div className="bg-gradient-to-r from-[#0B2A6F] via-[#1769E0] to-[#0FB5A0] rounded-3xl p-5 text-white shadow-xl shadow-blue-900/20 relative overflow-hidden">
              <div className="absolute right-[-10px] bottom-[-10px] opacity-15">
                <Heart className="w-36 h-36" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-white border border-white/30 inline-block">
                Your Health, Our Priority
              </span>
              <h2 className="font-extrabold text-lg mt-2 mb-1 tracking-tight">Take care of your health with HealthPilot</h2>
              <p className="text-xs text-blue-100 font-medium">Better Care Made Simple • Noida Sec-63</p>
            </div>

            {/* Universal Search Bar */}
            <div className="relative">
              <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder={language === 'en' ? "Search doctor, test, medicine..." : "डॉक्टर, टेस्ट, दवा खोजें..."}
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className={`w-full ${isDarkMode ? 'bg-slate-850 text-white border-slate-700/80' : 'bg-white text-slate-900 border-slate-200'} pl-10 pr-4 py-3.5 rounded-2xl border text-sm font-medium focus:outline-none focus:border-[#1769E0] focus:ring-2 focus:ring-[#1769E0]/20 shadow-xs transition-all`}
              />
            </div>

            {/* 3 Big Gradient Cards */}
            <div className="space-y-3">
              {/* Doctor Consultation Card (Blue) */}
              <div 
                onClick={() => setActiveTab('consultation')}
                className="bg-gradient-to-r from-[#1769E0] to-blue-700 rounded-3xl p-4 text-white shadow-lg shadow-blue-500/20 cursor-pointer hover:scale-[1.015] active:scale-[0.985] transition-all flex items-center justify-between"
              >
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/20">Top Specialists</span>
                  <h3 className="font-extrabold text-base mt-1">Doctor Consultation</h3>
                  <p className="text-xs text-blue-100 mt-0.5">Video, Audio, Chat or In-Clinic</p>
                </div>
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shrink-0 border border-white/20 shadow-inner">
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
              </div>

              {/* Book Lab Tests Card (Teal) */}
              <div 
                onClick={() => setActiveTab('tests')}
                className="bg-gradient-to-r from-[#0FB5A0] to-teal-700 rounded-3xl p-4 text-white shadow-lg shadow-teal-500/20 cursor-pointer hover:scale-[1.015] active:scale-[0.985] transition-all flex items-center justify-between"
              >
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/20">NABL Accredited</span>
                  <h3 className="font-extrabold text-base mt-1">Book Lab Tests</h3>
                  <p className="text-xs text-teal-100 mt-0.5">Free Home Sample Collection</p>
                </div>
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shrink-0 border border-white/20 shadow-inner">
                  <Activity className="w-6 h-6 text-white" />
                </div>
              </div>

              {/* Order Medicines Card (Green - Pharmacist Aligned) */}
              <div 
                onClick={() => setActiveTab('medicines')}
                className="bg-gradient-to-r from-[#10B981] to-emerald-700 rounded-3xl p-4 text-white shadow-lg shadow-emerald-500/20 cursor-pointer hover:scale-[1.015] active:scale-[0.985] transition-all flex items-center justify-between"
              >
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/20">Up to 25% Off</span>
                  <h3 className="font-extrabold text-base mt-1">Order Medicines</h3>
                  <p className="text-xs text-emerald-100 mt-0.5">Instant delivery & Rx upload</p>
                </div>
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shrink-0 border border-white/20 shadow-inner">
                  <ShoppingBag className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>

            {/* Quick Access Row with Colourful Icon Badges */}
            <div className="grid grid-cols-4 gap-2.5">
              <button 
                onClick={() => setActiveTab('profile')} 
                className={`${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'} p-3 rounded-2xl shadow-xs border flex flex-col items-center text-center hover:scale-105 transition-transform`}
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#1769E0] to-blue-500 text-white flex items-center justify-center mb-1.5 shadow-md shadow-blue-500/25">
                  <FileText className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-extrabold text-slate-800 dark:text-slate-200">Records</span>
              </button>
              <button 
                onClick={() => setShowReportViewer(true)} 
                className={`${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'} p-3 rounded-2xl shadow-xs border flex flex-col items-center text-center hover:scale-105 transition-transform`}
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#0FB5A0] to-teal-500 text-white flex items-center justify-center mb-1.5 shadow-md shadow-teal-500/25">
                  <Activity className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-extrabold text-slate-800 dark:text-slate-200">Reports</span>
              </button>
              <button 
                onClick={() => showToast('Coupon MS25 applied successfully! 25% discount active.')} 
                className={`${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'} p-3 rounded-2xl shadow-xs border flex flex-col items-center text-center hover:scale-105 transition-transform`}
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-400 to-amber-500 text-slate-950 flex items-center justify-center mb-1.5 shadow-md shadow-amber-500/25">
                  <Zap className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-extrabold text-slate-800 dark:text-slate-200">Offers</span>
              </button>
              <button 
                onClick={() => showToast('Support chat connected with executive.')} 
                className={`${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'} p-3 rounded-2xl shadow-xs border flex flex-col items-center text-center hover:scale-105 transition-transform`}
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-purple-500 text-white flex items-center justify-center mb-1.5 shadow-md shadow-purple-500/25">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-extrabold text-slate-800 dark:text-slate-200">Support</span>
              </button>
            </div>

            {/* Real-time Pharmacy Order Status Tracker */}
            <PharmacyOrderTracker isDarkMode={isDarkMode} onGoToPharmacy={() => setActiveTab('medicines')} />

            {/* My Bookings Tracker Section */}
            <div className={`${isDarkMode ? 'bg-slate-900/85 border-slate-800' : 'bg-white/90 border-slate-200'} p-4 rounded-3xl border shadow-sm backdrop-blur-md`}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">Active Consultations & Lab Bookings</h4>
                <span className="text-xs text-[#1769E0] font-extrabold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#1769E0] animate-ping" /> Live Tracker
                </span>
              </div>
              <div className="space-y-2">
                {labBookings.slice(0, 2).map((lb) => (
                  <div key={lb.id} className="p-3 bg-teal-500/10 border border-teal-500/30 rounded-2xl flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-extrabold text-teal-700 dark:text-teal-300 bg-teal-500/20 px-2 py-0.5 rounded-full border border-teal-500/30">Lab Test</span>
                      <h5 className="font-bold text-xs mt-1 text-slate-900 dark:text-white">{lb.testName}</h5>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">{lb.status} • {lb.dateTime}</p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-teal-500/20 flex items-center justify-center text-teal-600">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                  </div>
                ))}
                {appointments.slice(0, 2).map((ap) => (
                  <div key={ap.id} className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-2xl flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-extrabold text-blue-700 dark:text-blue-300 bg-blue-500/20 px-2 py-0.5 rounded-full border border-blue-500/30">Consultation</span>
                      <h5 className="font-bold text-xs mt-1 text-slate-900 dark:text-white">{ap.doctorName} ({ap.doctorSpecialty})</h5>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">{ap.status} • {ap.mode} Call</p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-600">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                  </div>
                ))}
                {labBookings.length === 0 && appointments.length === 0 && (
                  <div className="p-4 bg-slate-500/5 rounded-2xl text-center">
                    <Clock className="w-6 h-6 text-slate-400 mx-auto mb-1.5 opacity-60" />
                    <p className="text-xs font-bold text-slate-400">No active consultations or lab bookings</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">Your doctor appointments and lab sample collections will track live here.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-3 pb-2">
              <div className={`${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'} p-3 rounded-2xl border flex items-center gap-3 shadow-xs`}>
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-[#1769E0] flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h6 className="font-extrabold text-xs text-slate-900 dark:text-white">Verified Doctors</h6>
                  <p className="text-[10px] text-slate-400">100% NMC Panel</p>
                </div>
              </div>
              <div className={`${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'} p-3 rounded-2xl border flex items-center gap-3 shadow-xs`}>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-[#10B981] flex items-center justify-center shrink-0">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h6 className="font-extrabold text-xs text-slate-900 dark:text-white">Safe Delivery</h6>
                  <p className="text-[10px] text-slate-400">Cold Chain Sealed</p>
                </div>
              </div>
            </div>

            {/* Special Panels / Health Check-ups Preview (Top 4) */}
            <div className="space-y-3 pt-1">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">Health Packages & Full Body Checkups</h4>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">NABL certified comprehensive profiles with home collection</p>
                </div>
                <button
                  onClick={() => {
                    setSelectedTestCategory('Special Panels');
                    setActiveTab('tests');
                  }}
                  className="text-xs font-bold text-[#8B5CF6] hover:underline flex items-center shrink-0 ml-2"
                >
                  View All (140+) <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {specialPanelsPreview.map(panel => {
                  const pPrice = getPatientPrice(panel.labRate);
                  return (
                    <div 
                      key={panel.id} 
                      className={`${isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm flex flex-col justify-between hover:border-purple-400/50 transition-all`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="text-[10px] font-extrabold text-[#8B5CF6] bg-purple-500/10 border border-purple-500/20 px-2 py-0.5 rounded-full">
                            {panel.category}
                          </span>
                          <span className="text-[10px] text-slate-400 flex items-center gap-1 font-semibold">
                            <Clock className="w-3 h-3 text-slate-400" /> {panel.tat}
                          </span>
                        </div>
                        <h5 className="font-extrabold text-xs text-slate-900 dark:text-white leading-snug">
                          {panel.name}
                        </h5>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                          {panel.description}
                        </p>
                        {panel.includes && panel.includes.length > 0 && (
                          <div className="mt-2 text-[10px] text-teal-600 dark:text-teal-400 font-bold bg-teal-500/10 px-2 py-1 rounded-xl">
                            Includes {panel.parametersCount} Parameters ({panel.includes.slice(0, 3).join(', ')}...)
                          </div>
                        )}
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-semibold">Total Package Price</span>
                          <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                            {formatINR(pPrice)}
                          </span>
                        </div>
                        <button
                          onClick={() => setSelectedTestForBooking(panel)}
                          className="px-3.5 py-1.5 bg-[#0FB5A0] hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/20 transition-all"
                        >
                          Book Now
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* 2. DOCTOR CONSULTATION TAB */}
        {activeTab === 'consultation' && (
          <div className="p-4 space-y-4">
            <h2 className="font-extrabold text-base">Consult Expert Doctors</h2>

            {/* Specialty Filter Chips */}
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {['All', 'General Physician', 'Cardiologist', 'Gynaecologist', 'Diabetologist'].map(spec => (
                <button 
                  key={spec}
                  onClick={() => setSelectedSpecialty(spec)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${selectedSpecialty === spec ? 'bg-[#1769E0] text-white shadow-md' : 'bg-white text-slate-700 border border-slate-200'}`}
                >
                  {spec}
                </button>
              ))}
            </div>

            {/* Doctor Cards */}
            <div className="space-y-3">
              {filteredDoctors.length === 0 ? (
                <div className="p-8 text-center bg-slate-500/5 rounded-3xl border border-slate-500/10">
                  <Stethoscope className="w-10 h-10 text-slate-400 mx-auto mb-2 opacity-50" />
                  <p className="font-bold text-sm text-slate-700 dark:text-slate-300">No doctors available right now</p>
                  <p className="text-xs text-slate-400 mt-1">Please check back soon as verified medical practitioners come online.</p>
                </div>
              ) : (
                filteredDoctors.map(doc => (
                  <div key={doc.id} className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm flex gap-3.5`}>
                    <img src={doc.avatarUrl} alt={doc.name} className="w-16 h-16 rounded-2xl object-cover shrink-0 border border-slate-200" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-extrabold text-sm">{doc.name}</h3>
                        <div className="flex items-center gap-1 text-xs font-bold text-amber-600 bg-amber-500/10 px-2 py-0.5 rounded-full">
                          <Star className="w-3 h-3 fill-amber-500 text-amber-500" /> {doc.rating}
                        </div>
                      </div>
                      <p className="text-xs text-[#1769E0] font-bold">{doc.specialty}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{doc.qualification} • {doc.experienceYears} yrs exp</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">{doc.hospital}</p>
                      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="text-xs text-slate-400">Fee:</span>
                          <span className="text-sm font-extrabold ml-1">₹{doc.consultationFee}</span>
                        </div>
                        <button 
                          onClick={() => setSelectedDoctorForBooking(doc)}
                          className="px-4 py-2 bg-[#1769E0] hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md"
                        >
                          Book Slot
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* 3. LAB TESTS TAB */}
        {activeTab === 'tests' && (
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-extrabold text-base">Lab Tests & Health Packages</h2>
              <span className="text-[10px] font-bold text-slate-500">{filteredLabTests.length} tests found</span>
            </div>

            {/* Filters & Search */}
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search tests, categories, samples..."
                  value={testSearchQuery}
                  onChange={e => setTestSearchQuery(e.target.value)}
                  className={`w-full ${isDarkMode ? 'bg-slate-850 text-white border-slate-700/80' : 'bg-white text-slate-900 border-slate-200'} pl-10 pr-4 py-3 rounded-2xl border text-sm font-medium focus:outline-none focus:border-[#0FB5A0] focus:ring-2 focus:ring-[#0FB5A0]/20 transition-all`}
                />
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                {['All', ...LAB_TEST_CATEGORIES].map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setSelectedTestCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${selectedTestCategory === cat ? 'bg-[#0FB5A0] text-white shadow-md' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={testSortBy}
                  onChange={e => setTestSortBy(e.target.value as any)}
                  className={`flex-1 p-2 rounded-xl text-xs font-semibold border ${isDarkMode ? 'bg-slate-850 text-white border-slate-700' : 'bg-white text-slate-900 border-slate-200'}`}
                >
                  <option value="default">Sort: Default</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="name_asc">Name: A to Z</option>
                </select>
              </div>
            </div>

            {/* Tests List */}
            <div className="space-y-3">
              {visibleLabTests.length === 0 ? (
                <div className="p-8 text-center bg-slate-500/5 rounded-3xl border border-slate-500/10">
                  <p className="font-bold text-sm text-slate-700 dark:text-slate-300">No tests found</p>
                </div>
              ) : (
                visibleLabTests.map(test => (
                  <div key={test.id} className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm`}>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="text-[10px] font-extrabold text-[#0FB5A0] bg-teal-500/10 px-2 py-0.5 rounded-full">{test.category}</span>
                          {test.fastingRequired && <span className="text-[10px] font-extrabold text-amber-600 bg-amber-500/10 px-2.5 py-0.5 rounded-full">Fasting Required</span>}
                        </div>
                        <h3 className="font-extrabold text-sm leading-snug">{test.name}</h3>
                        <p className="text-[11px] text-slate-500 mt-1">{test.sampleType} • {test.tat}</p>
                        
                        {test.isPanel && test.includes && (
                          <div className="mt-2">
                            <button 
                              onClick={() => togglePanelExpand(test.id)}
                              className="text-[10px] font-bold text-[#8B5CF6] flex items-center gap-1"
                            >
                              {expandedPanelIds.has(test.id) ? <ChevronUp className="w-3 h-3"/> : <ChevronDown className="w-3 h-3"/>}
                              {expandedPanelIds.has(test.id) ? 'Hide Includes' : `Includes ${test.parameters} items`}
                            </button>
                            {expandedPanelIds.has(test.id) && (
                              <ul className="text-[10px] text-slate-500 mt-1.5 list-disc pl-4 space-y-0.5">
                                {test.includes.map((inc, i) => <li key={i}>{inc}</li>)}
                              </ul>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-base font-extrabold">{formatINR(getPatientPrice(test.labRate))}</span>
                      <button 
                        onClick={() => setSelectedTestForBooking(test)}
                        className="px-4 py-2 bg-[#0FB5A0] hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md transition-all"
                      >
                        Book Now
                      </button>
                    </div>
                  </div>
                ))
              )}
              {testsVisibleCount < filteredLabTests.length && (
                <button 
                  onClick={() => setTestsVisibleCount(prev => prev + 20)}
                  className="w-full py-3 rounded-2xl text-xs font-bold text-[#0FB5A0] hover:bg-teal-500/10 border border-[#0FB5A0]/20 transition-all"
                >
                  Load More Tests
                </button>
              )}
              <p className="text-[10px] text-slate-400 text-center mt-4">Prices are indicative and may change. This is a test version with demo data.</p>
            </div>
          </div>
        )}

        {/* 4. MEDICINES TAB */}
        {activeTab === 'medicines' && (
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white">Online Pharmacy</h2>
              <button 
                onClick={() => setShowCart(true)}
                className="relative px-3.5 py-1.5 bg-gradient-to-r from-[#10B981] to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-emerald-500/25 transition-all"
              >
                <ShoppingBag className="w-4 h-4" /> Cart ({cartMedicines.reduce((acc, item) => acc + item.quantity, 0)})
              </button>
            </div>

            {/* Real-time Pharmacy Order Status Tracker */}
            <PharmacyOrderTracker isDarkMode={isDarkMode} />

            {/* Category Chips */}
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {['All', 'Diabetes', 'Heart', 'Ayurveda', 'Wellness', 'General'].map(cat => (
                <button 
                  key={cat}
                  onClick={() => setSelectedMedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all ${
                    selectedMedCategory === cat 
                      ? 'bg-gradient-to-r from-[#10B981] to-emerald-600 text-white shadow-md shadow-emerald-500/20' 
                      : 'bg-white/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Rx Upload Banner */}
            <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-3xl flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-tr from-[#10B981] to-emerald-600 text-white rounded-2xl flex items-center justify-center shrink-0 shadow-md shadow-emerald-500/20">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Upload Prescription</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Pharmacist verifies & packs medicines.</p>
                </div>
              </div>
              <button 
                disabled={isUploadingRx || activePharmacists.length === 0}
                onClick={async () => {
                  if (activePharmacists.length === 0) {
                    showToast('No active verified pharmacies available for prescription processing.');
                    return;
                  }
                  if (!isProfileComplete) {
                    showToast('Please complete your phone number and delivery address in your Profile first.');
                    setShowEditProfileModal(true);
                    return;
                  }
                  setIsUploadingRx(true);
                  try {
                    await createPharmacyOrder({
                      patientId: currentUser!.id,
                      patientName: currentUser!.name,
                      patientPhone: currentUser!.phone,
                      pharmacyId: activePharmacists[0].id,
                      items: [{ medicineId: 'rx-doc-upload', medicineName: 'Prescription Dispensation', quantity: 1, price: 450 }],
                      totalAmount: 450,
                      status: 'Placed',
                      orderDate: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
                      deliveryAddress: (currentUser as PatientProfile).address,
                      rxAttached: true,
                      rxImageUrl: 'Prescription_Uploaded.pdf'
                    });
                    showToast('Prescription uploaded & sent to pharmacy for verification!');
                  } catch (err: any) {
                    showToast(err?.message || 'Failed to upload prescription. Please try again.');
                  } finally {
                    setIsUploadingRx(false);
                  }
                }}
                className={`px-3.5 py-2 text-white rounded-xl text-xs font-extrabold shrink-0 shadow-md transition-all flex items-center gap-1.5 ${
                  isUploadingRx || activePharmacists.length === 0
                    ? 'bg-slate-400 dark:bg-slate-700 cursor-not-allowed opacity-60'
                    : 'bg-gradient-to-r from-[#10B981] to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-emerald-500/25'
                }`}
              >
                {isUploadingRx ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Uploading...
                  </>
                ) : activePharmacists.length === 0 ? (
                  'No Pharmacy'
                ) : (
                  'Upload Rx'
                )}
              </button>
            </div>

            <div className="space-y-3">
              {filteredMedicines.map(med => (
                <div key={med.id} className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm flex items-center gap-3.5`}>
                  <img src={med.imageUrl} alt={med.name} className="w-16 h-16 rounded-2xl object-cover shrink-0 border border-slate-100" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-extrabold text-violet-600 bg-violet-500/10 px-2 py-0.5 rounded-full">{med.category}</span>
                      {med.requiresRx && <span className="text-[10px] font-extrabold text-red-600 bg-red-500/10 px-2 py-0.5 rounded-full">Rx Required</span>}
                    </div>
                    <h3 className="font-extrabold text-xs mt-1">{med.name}</h3>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{med.salt}</p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm">₹{med.discountPrice}</span>
                        <span className="text-xs text-slate-400 line-through">₹{med.price}</span>
                      </div>
                      <button 
                        onClick={() => handleAddToCart(med)}
                        className="px-3 py-1.5 bg-[#0B2A6F] hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md"
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. PROFILE & EXTRAS TAB */}
        {activeTab === 'profile' && (
          <div className="p-4 space-y-4">
            <div className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-5 rounded-3xl border shadow-sm text-center relative`}>
              <button 
                onClick={() => setShowEditProfileModal(true)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-[#1769E0] rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                title="Edit Profile"
              >
                <Edit3 className="w-4 h-4" />
              </button>

              <div className="w-20 h-20 bg-gradient-to-tr from-[#0B2A6F] to-[#1769E0] text-white rounded-full flex items-center justify-center text-2xl font-extrabold mx-auto mb-3 shadow-lg">
                {(currentUser?.name || 'PT')
                  .split(' ')
                  .map(n => n[0])
                  .join('')
                  .slice(0, 2)
                  .toUpperCase()}
              </div>
              <h3 className="font-extrabold text-base">{currentUser?.name || 'HealthPilot Patient'}</h3>
              <p className="text-xs text-slate-400">
                {currentUser?.phone ? currentUser.phone : 'No phone linked'} • {(currentUser as PatientProfile)?.address || 'No address linked'}
              </p>

              {!isProfileComplete && (
                <div className="mt-3 p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-between text-left">
                  <div>
                    <p className="text-xs font-bold text-amber-500">Incomplete Profile</p>
                    <p className="text-[11px] text-slate-400">Phone and address are required to book doctors, tests, and medicines.</p>
                  </div>
                  <button
                    onClick={() => setShowEditProfileModal(true)}
                    className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-extrabold shrink-0"
                  >
                    Complete
                  </button>
                </div>
              )}
              
              <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-100 dark:border-slate-700 text-center">
                <div>
                  <span className="text-[10px] text-slate-400 block font-bold">Blood Group</span>
                  <strong className="text-sm">{(currentUser as PatientProfile)?.bloodGroup || 'Not set'}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-bold">Age / Gender</span>
                  <strong className="text-sm">
                    {((currentUser as PatientProfile)?.age || '--')} / {((currentUser as PatientProfile)?.gender || '--')}
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-bold">Wallet</span>
                  <strong className="text-[#0FB5A0] text-sm">₹ {(currentUser as PatientProfile)?.walletBalance ?? 0}</strong>
                </div>
              </div>
            </div>

            {/* Founder Contact Card (Mandatory Requirement) */}
            <div className="bg-gradient-to-r from-[#0B2A6F] to-[#1769E0] p-5 rounded-3xl text-white shadow-lg space-y-2">
              <div className="flex items-center gap-3">
                <FounderAvatar className="w-14 h-14 rounded-full border-2 border-white/30 shadow-md object-cover object-top" />
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block mb-1">Leadership</span>
                  <h4 className="font-extrabold text-sm">Founder & Director Contact</h4>
                  <p className="text-xs font-bold text-blue-100">{founderDetails.name}</p>
                </div>
              </div>
              <p className="text-xs text-blue-200 pt-1">Phone / WhatsApp: <a href={`tel:${founderDetails.phone}`} className="underline font-mono">{founderDetails.phone}</a></p>
              <p className="text-[11px] text-blue-200">Office: {founderDetails.office}</p>
            </div>

            {/* Family Members Vault */}
            <div className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm`}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-extrabold text-sm">Family Members Vault</h4>
                <button 
                  onClick={() => setShowAddFamilyModal(true)} 
                  className="text-xs text-[#1769E0] font-bold flex items-center gap-1 hover:underline"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Member
                </button>
              </div>
              <div className="space-y-2">
                {familyMembers.length === 0 ? (
                  <div className="p-4 bg-slate-500/5 rounded-2xl text-center text-xs text-slate-400">
                    No family members added yet. Add family members to easily book appointments on their behalf.
                  </div>
                ) : (
                  familyMembers.map(fm => (
                    <div key={fm.id} className="flex items-center justify-between p-3 bg-slate-500/10 rounded-2xl border border-slate-500/20">
                      <div>
                        <span className="font-extrabold text-xs">{fm.name}</span>
                        <p className="text-[11px] text-slate-400">{fm.relation} • {fm.age} yrs • {fm.bloodGroup}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-teal-600 font-bold bg-teal-500/10 px-2 py-0.5 rounded-full">Active</span>
                        <button
                          onClick={async () => {
                            try {
                              const updated = familyMembers.filter(m => m.id !== fm.id);
                              await updateFamilyMembers(updated);
                              showToast(`Removed ${fm.name} from family vault`);
                            } catch (err: any) {
                              showToast(err?.message || 'Failed to remove member.');
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
                          title="Remove family member"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Health Records Vault */}
            <div className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm`}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-extrabold text-sm">Health Records Vault</h4>
                <button onClick={() => showToast('Secure time-limited doctor sharing link copied!')} className="text-xs text-[#0FB5A0] font-bold">Share Link</button>
              </div>
              <div className="space-y-2">
                {healthRecordsLoading ? (
                  <div className="p-4 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-[#0FB5A0]" /> Loading health records...
                  </div>
                ) : healthRecords.length === 0 ? (
                  <div className="p-4 bg-slate-500/5 rounded-2xl text-center text-xs text-slate-400">
                    <FileText className="w-6 h-6 text-slate-400 mx-auto mb-1.5 opacity-60" />
                    <p className="font-bold text-slate-400">No health records recorded yet</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">Completed prescriptions and verified lab reports will appear here automatically.</p>
                  </div>
                ) : (
                  healthRecords.map(rec => (
                    <div key={rec.id} className="flex items-center justify-between p-3 bg-slate-500/10 rounded-2xl border border-slate-500/20">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400">{rec.type} • {rec.date}</span>
                        <h5 className="font-bold text-xs mt-0.5">{rec.title}</h5>
                        <p className="text-[10px] text-slate-500">{rec.doctorOrLab}</p>
                      </div>
                      <button onClick={() => showToast(`Downloading ${rec.title}...`)} className="p-2 bg-slate-200 dark:bg-slate-700 rounded-xl hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* App Preferences */}
            <div className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} p-4 rounded-3xl border shadow-sm space-y-3`}>
              <h4 className="font-extrabold text-sm">Preferences & Accessibility</h4>
              <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
                <span className="text-xs font-semibold">Senior Large Font Mode</span>
                <button onClick={onToggleFont} className={`w-11 h-6 rounded-full transition-colors relative ${isLargeFont ? 'bg-[#1769E0]' : 'bg-slate-300'}`}>
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${isLargeFont ? 'left-5.5' : 'left-0.5'}`} />
                </button>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-xs font-semibold">Language Switch</span>
                <button onClick={onToggleLanguage} className="px-3 py-1 bg-slate-100 dark:bg-slate-700 text-xs font-bold rounded-xl">
                  {language === 'en' ? 'English' : 'हिंदी'}
                </button>
              </div>
            </div>

          </div>
        )}
      </main>

      {/* Lab Test Booking Modal */}
      {selectedTestForBooking && (
        <div className="absolute inset-0 bg-black/70 z-50 flex items-end justify-center backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full rounded-t-[36px] p-6 shadow-2xl animate-slide-up max-h-[80vh] overflow-y-auto`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-extrabold text-base">Book Lab Test</h3>
              <button onClick={() => setSelectedTestForBooking(null)} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"><X className="w-5 h-5" /></button>
            </div>
            
            <div className="bg-[#0FB5A0]/10 p-4 rounded-3xl border border-[#0FB5A0]/30 mb-4">
              <h4 className="font-extrabold text-sm">{selectedTestForBooking.name}</h4>
              <p className="text-xs text-slate-500 mt-1">{selectedTestForBooking.description}</p>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-[#0FB5A0]/20">
                <span className="font-extrabold text-[#0FB5A0] text-lg">{formatINR(getPatientPrice(selectedTestForBooking.labRate))}</span>
                <span className="text-xs font-bold text-teal-600">{selectedTestForBooking.parameters} Parameters Included</span>
              </div>
            </div>

            <div className="space-y-3 mb-5">
              <div>
                <label className="text-xs font-bold block mb-1">Select Diagnostic Lab</label>
                {activeLabs.length === 0 ? (
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-xs text-amber-500 font-semibold mb-3">
                    No verified diagnostic labs are currently active. Please check back later.
                  </div>
                ) : (
                  <select
                    value={selectedLabId || activeLabs[0]?.id}
                    onChange={e => setSelectedLabId(e.target.value)}
                    className={`w-full p-3 rounded-2xl text-xs font-semibold border mb-3 ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    {activeLabs.map(lab => (
                      <option key={lab.id} value={lab.id}>
                        {lab.labName} • {lab.accreditation} Certified
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="text-xs font-bold block mb-1">Collection Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  <button className="py-3 bg-[#0FB5A0] text-white rounded-2xl text-xs font-bold shadow-md">Home Collection (Free)</button>
                  <button className="py-3 bg-slate-200 dark:bg-slate-700 rounded-2xl text-xs font-bold">Visit Lab (10% Off)</button>
                </div>
              </div>
            </div>

            <button 
              disabled={isBookingLab || activeLabs.length === 0}
              onClick={async () => {
                if (activeLabs.length === 0) {
                  showToast('No active diagnostic labs available to fulfill this booking.');
                  return;
                }
                if (!isProfileComplete) {
                  showToast('Please complete your phone number and delivery address before booking.');
                  setShowEditProfileModal(true);
                  return;
                }
                const test = selectedTestForBooking;
                const labId = selectedLabId || activeLabs[0].id;
                setIsBookingLab(true);
                try {
                  await createLabBooking({
                    patientId: currentUser!.id,
                    patientName: currentUser!.name,
                    patientPhone: currentUser!.phone,
                    testId: test.id,
                    testName: test.name,
                    collectionType: 'Home Collection',
                    dateTime: 'Tomorrow, 7:00 AM',
                    address: (currentUser as PatientProfile).address,
                    status: 'Confirmed',
                    assignedLabId: labId,
                    amount: getPatientPrice(test.labRate)
                  });
                  setSelectedTestForBooking(null);
                  showToast('Lab test booked successfully! Phlebotomist assigned.');
                } catch (err: any) {
                  showToast(err?.message || 'Failed to book lab test. Please try again.');
                } finally {
                  setIsBookingLab(false);
                }
              }}
              className={`w-full py-4 text-white rounded-2xl font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition-all ${
                isBookingLab || activeLabs.length === 0
                  ? 'bg-slate-400 dark:bg-slate-700 cursor-not-allowed opacity-60'
                  : 'bg-[#0FB5A0] hover:bg-teal-700'
              }`}
            >
              {isBookingLab ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Processing Booking...
                </>
              ) : activeLabs.length === 0 ? (
                'No Active Labs Available'
              ) : (
                `Confirm & Pay ${formatINR(getPatientPrice(selectedTestForBooking.labRate))}`
              )}
            </button>
          </div>
        </div>
      )}

      {/* Doctor Booking Modal */}
      {selectedDoctorForBooking && (
        <div className="absolute inset-0 bg-black/70 z-50 flex items-end justify-center backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full rounded-t-[36px] p-6 shadow-2xl animate-slide-up max-h-[80vh] overflow-y-auto`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-extrabold text-base">Confirm Consultation</h3>
              <button onClick={() => setSelectedDoctorForBooking(null)} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"><X className="w-5 h-5" /></button>
            </div>

            <div className="flex items-center gap-3.5 p-4 bg-blue-500/10 border border-blue-500/30 rounded-3xl mb-4">
              <img src={selectedDoctorForBooking.avatarUrl} alt="" className="w-14 h-14 rounded-2xl object-cover" />
              <div>
                <h4 className="font-extrabold text-sm">{selectedDoctorForBooking.name}</h4>
                <p className="text-xs text-[#1769E0] font-bold">{selectedDoctorForBooking.specialty}</p>
                <p className="text-[11px] text-slate-400">{selectedDoctorForBooking.hospital}</p>
              </div>
            </div>

            <div className="space-y-3 mb-5">
              <div>
                <label className="text-xs font-bold block mb-1">Consultation Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  <button className="py-3 bg-[#1769E0] text-white rounded-2xl text-xs font-bold shadow-md">Video (₹{selectedDoctorForBooking.consultationFee})</button>
                  <button className="py-3 bg-slate-200 dark:bg-slate-700 rounded-2xl text-xs font-bold">Clinic Visit (₹{selectedDoctorForBooking.consultationFee})</button>
                </div>
              </div>
            </div>

            <button 
              disabled={isBookingDoctor}
              onClick={async () => {
                if (!isProfileComplete) {
                  showToast('Please complete your phone number and address in your Profile before booking.');
                  setShowEditProfileModal(true);
                  return;
                }
                const doc = selectedDoctorForBooking;
                setIsBookingDoctor(true);
                try {
                  await createAppointment({
                    patientId: currentUser!.id,
                    patientName: currentUser!.name,
                    patientAge: (currentUser as PatientProfile).age || 0,
                    patientGender: (currentUser as PatientProfile).gender || 'Other',
                    doctorId: doc.id,
                    doctorName: doc.name,
                    doctorSpecialty: doc.specialty,
                    mode: 'Video',
                    dateTime: 'Today, Immediate',
                    status: 'Scheduled',
                    fee: doc.consultationFee,
                    symptoms: 'General consultation'
                  });
                  setSelectedDoctorForBooking(null);
                  setActiveConsultationRoom(doc);
                  showToast('Appointment confirmed! Joining video room...');
                } catch (err: any) {
                  showToast(err?.message || 'Failed to confirm appointment. Please try again.');
                } finally {
                  setIsBookingDoctor(false);
                }
              }}
              className={`w-full py-4 text-white rounded-2xl font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition-all ${
                isBookingDoctor ? 'bg-slate-400 cursor-not-allowed opacity-60' : 'bg-[#1769E0] hover:bg-blue-700'
              }`}
            >
              {isBookingDoctor ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Scheduling Appointment...
                </>
              ) : (
                `Proceed to Pay ₹${selectedDoctorForBooking.consultationFee}`
              )}
            </button>
          </div>
        </div>
      )}

      {/* Cart Modal */}
      {showCart && (
        <div className="absolute inset-0 bg-black/70 z-50 flex items-end justify-center backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full rounded-t-[36px] p-6 shadow-2xl animate-slide-up max-h-[80vh] overflow-y-auto`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-extrabold text-base">Pharmacy Cart</h3>
              <button onClick={() => setShowCart(false)} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"><X className="w-5 h-5" /></button>
            </div>

            {cartMedicines.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">Your cart is empty. Add medicines from catalog.</div>
            ) : (
              <div className="space-y-3 mb-5">
                {cartMedicines.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-slate-500/10 p-3.5 rounded-2xl border border-slate-500/20">
                    <div>
                      <h4 className="font-extrabold text-xs">{item.medicine.name}</h4>
                      <p className="text-[11px] text-slate-400">₹{item.medicine.discountPrice} × {item.quantity}</p>
                    </div>
                    <span className="font-extrabold text-sm">₹{item.medicine.discountPrice * item.quantity}</span>
                  </div>
                ))}

                {/* Fulfillment Pharmacy Selector */}
                <div>
                  <label className="text-xs font-bold block mb-1">Fulfillment Pharmacy</label>
                  {activePharmacists.length === 0 ? (
                    <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-xs text-amber-500 font-semibold mb-2">
                      No verified pharmacies are currently active. Please check back later.
                    </div>
                  ) : (
                    <select
                      value={selectedPharmacyId || activePharmacists[0]?.id}
                      onChange={e => setSelectedPharmacyId(e.target.value)}
                      className={`w-full p-3 rounded-2xl text-xs font-semibold border mb-2 ${
                        isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    >
                      {activePharmacists.map(ph => (
                        <option key={ph.id} value={ph.id}>
                          {ph.pharmacyName} ({ph.pharmacyAddress || ph.name})
                        </option>
                      ))}
                    </select>
                  )}
                </div>
                
                <div className="pt-3 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <span className="font-extrabold text-sm">Total Amount</span>
                  <span className="font-extrabold text-[#6D4FE0] text-lg">
                    ₹{cartMedicines.reduce((sum, item) => sum + item.medicine.discountPrice * item.quantity, 0)}
                  </span>
                </div>

                <button 
                  disabled={isPlacingOrder || activePharmacists.length === 0}
                  onClick={async () => {
                    if (activePharmacists.length === 0) {
                      showToast('No active pharmacies available to fulfill your order.');
                      return;
                    }
                    if (!isProfileComplete) {
                      showToast('Please complete your phone number and delivery address before ordering.');
                      setShowEditProfileModal(true);
                      return;
                    }
                    const items = [...cartMedicines];
                    const total = items.reduce((sum, item) => sum + item.medicine.discountPrice * item.quantity, 0);
                    const pharmaId = selectedPharmacyId || activePharmacists[0].id;
                    setIsPlacingOrder(true);
                    try {
                      await createPharmacyOrder({
                        patientId: currentUser!.id,
                        patientName: currentUser!.name,
                        patientPhone: currentUser!.phone,
                        pharmacyId: pharmaId,
                        items: items.map(i => ({
                          medicineId: i.medicine.id,
                          medicineName: i.medicine.name,
                          quantity: i.quantity,
                          price: i.medicine.discountPrice
                        })),
                        totalAmount: total,
                        status: 'Placed',
                        orderDate: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
                        deliveryAddress: (currentUser as PatientProfile).address,
                        rxAttached: false
                      });
                      setShowCart(false);
                      setCartMedicines([]);
                      showToast('Order placed successfully! Delivery in 45 mins.');
                    } catch (err: any) {
                      showToast(err?.message || 'Failed to place order. Please try again.');
                    } finally {
                      setIsPlacingOrder(false);
                    }
                  }}
                  className={`w-full py-4 text-white rounded-2xl font-extrabold text-sm shadow-xl mt-3 flex items-center justify-center gap-2 transition-all ${
                    isPlacingOrder || activePharmacists.length === 0
                      ? 'bg-slate-400 dark:bg-slate-700 cursor-not-allowed opacity-60'
                      : 'bg-[#10B981] hover:bg-emerald-700'
                  }`}
                >
                  {isPlacingOrder ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Placing Order...
                    </>
                  ) : activePharmacists.length === 0 ? (
                    'No Active Pharmacy Available'
                  ) : (
                    'Place Order with UPI / COD'
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Active Consultation Room */}
      {activeConsultationRoom && (
        <div className="absolute inset-0 bg-slate-950 z-50 flex flex-col text-white">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={activeConsultationRoom.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover" />
              <div>
                <h4 className="font-bold text-sm">{activeConsultationRoom.name}</h4>
                <p className="text-[11px] text-teal-400 font-bold">Secure Video Consultation</p>
              </div>
            </div>
            <button onClick={() => setActiveConsultationRoom(null)} className="px-3 py-1.5 bg-red-600 rounded-xl text-xs font-bold">End Call</button>
          </div>
          <div className="flex-1 relative flex items-center justify-center p-4">
            <div className="w-full h-full rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 flex flex-col items-center justify-center">
              <div className="absolute top-4 left-4 bg-black/60 px-3 py-1 rounded-lg text-xs font-mono text-emerald-400">● Live 04:12</div>
              <Video className="w-16 h-16 text-[#1769E0] animate-pulse mb-3" />
              <h3 className="font-extrabold text-base">{activeConsultationRoom.name}</h3>
              <p className="text-xs text-slate-400 mt-1">Digital Prescription will be generated at end of call.</p>
            </div>
          </div>
        </div>
      )}

      {/* Lab Report Viewer Modal */}
      {showReportViewer && (
        <div className="absolute inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full max-h-[85vh] rounded-[36px] p-6 shadow-2xl overflow-y-auto`}>
            <div className="flex items-center justify-between mb-4 border-b pb-3">
              <HealthPilotLogo size="sm" />
              <button onClick={() => setShowReportViewer(false)} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"><X className="w-5 h-5" /></button>
            </div>
            <div className="mb-3">
              <h3 className="font-extrabold text-base">Thyroid & CBC Diagnostic Report</h3>
              <p className="text-[10px] text-slate-400">HealthPilot Central Diagnostics • NABL Accredited</p>
            </div>
            <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-3xl mb-4 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-extrabold text-emerald-600 text-xs">AI Summary: Normal Range</h4>
                <p className="text-[11px] text-slate-500">All parameters are within standard clinical thresholds.</p>
              </div>
            </div>
            <button 
              onClick={() => {
                setShowReportViewer(false);
                showToast('Official PDF Report downloaded');
              }}
              className="w-full py-3.5 bg-[#0FB5A0] text-white rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg"
            >
              <Download className="w-4 h-4" /> Download Official PDF Report
            </button>
          </div>
        </div>
      )}

      {/* Reschedule Appointment Modal */}
      {rescheduleAppt && (
        <div className="absolute inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full max-w-sm rounded-[32px] p-6 shadow-2xl space-y-4 animate-scale-in border border-slate-700/50`}>
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#1769E0]" />
                <h3 className="font-extrabold text-base">Reschedule Appointment</h3>
              </div>
              <button 
                onClick={() => setRescheduleAppt(null)} 
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-2xl space-y-1 text-xs">
              <p className="font-extrabold text-slate-900 dark:text-white">{rescheduleAppt.doctorName}</p>
              <p className="text-slate-500 dark:text-slate-400">{rescheduleAppt.doctorSpecialty} • {rescheduleAppt.mode}</p>
              <p className="text-[11px] text-[#1769E0] font-bold">Current Slot: {rescheduleAppt.dateTime}</p>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold block text-slate-700 dark:text-slate-300">
                Select New Preferred Slot:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  'Tomorrow, 10:00 AM',
                  'Tomorrow, 02:30 PM',
                  'Tomorrow, 06:00 PM',
                  'Day After, 11:30 AM'
                ].map(slot => (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => setRescheduleSlot(slot)}
                    className={`py-2 px-2.5 rounded-xl text-xs font-bold text-center border transition-all ${
                      rescheduleSlot === slot
                        ? 'bg-[#1769E0] text-white border-[#1769E0] shadow-sm'
                        : isDarkMode
                        ? 'bg-slate-700/60 text-slate-200 border-slate-600 hover:bg-slate-700'
                        : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    {slot}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold block text-slate-700 dark:text-slate-300">
                Reason for Rescheduling:
              </label>
              <select
                value={rescheduleReason}
                onChange={e => setRescheduleReason(e.target.value)}
                className={`w-full p-2.5 rounded-xl text-xs border ${
                  isDarkMode 
                    ? 'bg-slate-900 text-white border-slate-700' 
                    : 'bg-slate-50 text-slate-900 border-slate-200'
                }`}
              >
                <option value="Schedule conflict">Schedule conflict</option>
                <option value="Personal emergency">Personal emergency</option>
                <option value="Health feeling better">Health feeling better</option>
                <option value="Doctor suggested change">Doctor suggested change</option>
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={async () => {
                  const targetId = rescheduleAppt.id;
                  const newSlot = rescheduleSlot;
                  setRescheduleAppt(null);
                  try {
                    await updateAppointment(targetId, { dateTime: newSlot });
                  } catch (err) {
                    console.warn('Reschedule note:', err);
                  }
                  showToast(`Appointment rescheduled to ${newSlot}!`);
                }}
                className="flex-1 py-3 bg-gradient-to-r from-[#1769E0] to-[#0FB5A0] hover:from-blue-600 hover:to-teal-600 text-white rounded-2xl font-extrabold text-xs shadow-lg shadow-blue-500/25 transition-all text-center"
              >
                Confirm Reschedule
              </button>
              <button
                type="button"
                onClick={() => setRescheduleAppt(null)}
                className="px-4 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-2xl font-bold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Family Member Modal */}
      {showAddFamilyModal && (
        <div className="absolute inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full max-w-sm rounded-[32px] p-6 shadow-2xl space-y-4 animate-scale-in border border-slate-700/50`}>
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
              <h3 className="font-extrabold text-base">Add Family Member</h3>
              <button onClick={() => setShowAddFamilyModal(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold block mb-1">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. Ramesh Sharma"
                  value={newFmName}
                  onChange={e => setNewFmName(e.target.value)}
                  className={`w-full p-2.5 rounded-xl text-xs border ${
                    isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold block mb-1">Relationship</label>
                  <select
                    value={newFmRelation}
                    onChange={e => setNewFmRelation(e.target.value as any)}
                    className={`w-full p-2.5 rounded-xl text-xs border ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Son">Son</option>
                    <option value="Daughter">Daughter</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold block mb-1">Age</label>
                  <input
                    type="number"
                    placeholder="e.g. 58"
                    value={newFmAge}
                    onChange={e => setNewFmAge(e.target.value)}
                    className={`w-full p-2.5 rounded-xl text-xs border ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold block mb-1">Gender</label>
                  <select
                    value={newFmGender}
                    onChange={e => setNewFmGender(e.target.value as any)}
                    className={`w-full p-2.5 rounded-xl text-xs border ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold block mb-1">Blood Group</label>
                  <select
                    value={newFmBlood}
                    onChange={e => setNewFmBlood(e.target.value)}
                    className={`w-full p-2.5 rounded-xl text-xs border ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                disabled={isSavingFamily}
                onClick={async () => {
                  if (!newFmName.trim()) {
                    showToast('Please enter family member full name.');
                    return;
                  }
                  const ageNum = parseInt(newFmAge);
                  if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
                    showToast('Please enter a valid age between 1 and 120.');
                    return;
                  }
                  setIsSavingFamily(true);
                  try {
                    const newMember: FamilyMember = {
                      id: `FM-${Date.now().toString().slice(-6)}`,
                      name: newFmName.trim(),
                      relation: newFmRelation,
                      age: ageNum,
                      gender: newFmGender,
                      bloodGroup: newFmBlood
                    };
                    const updated = [...familyMembers, newMember];
                    await updateFamilyMembers(updated);
                    setShowAddFamilyModal(false);
                    setNewFmName('');
                    setNewFmAge('');
                    showToast(`Added ${newMember.name} to family members vault!`);
                  } catch (err: any) {
                    showToast(err?.message || 'Failed to save family member.');
                  } finally {
                    setIsSavingFamily(false);
                  }
                }}
                className={`flex-1 py-3 bg-gradient-to-r from-[#1769E0] to-[#0FB5A0] text-white rounded-2xl font-extrabold text-xs shadow-lg flex items-center justify-center gap-1.5 ${
                  isSavingFamily ? 'opacity-60 cursor-not-allowed' : ''
                }`}
              >
                {isSavingFamily ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                Save Member
              </button>
              <button
                onClick={() => setShowAddFamilyModal(false)}
                className="px-4 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-2xl font-bold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete / Edit Profile Modal */}
      {showEditProfileModal && (
        <div className="absolute inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className={`${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'} w-full max-w-sm rounded-[32px] p-6 shadow-2xl space-y-4 animate-scale-in border border-slate-700/50`}>
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
              <div>
                <h3 className="font-extrabold text-base">Complete Your Profile</h3>
                <p className="text-[11px] text-slate-400">Required for bookings, prescriptions, and deliveries.</p>
              </div>
              <button onClick={() => setShowEditProfileModal(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold block mb-1">Mobile Number (10 digits)</label>
                <input
                  type="tel"
                  placeholder="e.g. 9876543210"
                  value={editPhone}
                  onChange={e => setEditPhone(e.target.value)}
                  className={`w-full p-2.5 rounded-xl text-xs border ${
                    isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-bold block mb-1">Delivery / Home Address</label>
                <input
                  type="text"
                  placeholder="e.g. Flat 402, Tower B, Sector 62, Noida"
                  value={editAddress}
                  onChange={e => setEditAddress(e.target.value)}
                  className={`w-full p-2.5 rounded-xl text-xs border ${
                    isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold block mb-1">Age</label>
                  <input
                    type="number"
                    placeholder="e.g. 28"
                    value={editAge}
                    onChange={e => setEditAge(e.target.value)}
                    className={`w-full p-2.5 rounded-xl text-xs border ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  />
                </div>
                <div>
                  <label className="text-xs font-bold block mb-1">Blood Group</label>
                  <select
                    value={editBloodGroup}
                    onChange={e => setEditBloodGroup(e.target.value)}
                    className={`w-full p-2.5 rounded-xl text-xs border ${
                      isDarkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                disabled={isSavingProfile}
                onClick={async () => {
                  const cleanPhone = editPhone.replace(/[^0-9]/g, '').slice(-10);
                  if (!cleanPhone || cleanPhone.length !== 10) {
                    showToast('Please enter a valid 10-digit mobile number.');
                    return;
                  }
                  if (!editAddress.trim()) {
                    showToast('Please enter your delivery/home address.');
                    return;
                  }
                  const ageNum = parseInt(editAge) || 0;
                  setIsSavingProfile(true);
                  try {
                    await updatePatientProfile({
                      phone: `+91 ${cleanPhone}`,
                      address: editAddress.trim(),
                      age: ageNum,
                      bloodGroup: editBloodGroup
                    });
                    setShowEditProfileModal(false);
                    showToast('Profile updated successfully!');
                  } catch (err: any) {
                    showToast(err?.message || 'Failed to update profile.');
                  } finally {
                    setIsSavingProfile(false);
                  }
                }}
                className={`flex-1 py-3 bg-gradient-to-r from-[#1769E0] to-[#0FB5A0] text-white rounded-2xl font-extrabold text-xs shadow-lg flex items-center justify-center gap-1.5 ${
                  isSavingProfile ? 'opacity-60 cursor-not-allowed' : ''
                }`}
              >
                {isSavingProfile ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                Save Profile
              </button>
              <button
                onClick={() => setShowEditProfileModal(false)}
                className="px-4 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-2xl font-bold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation Bar (5 Tabs) */}
      <nav className={`fixed md:absolute bottom-0 left-0 right-0 md:max-w-[480px] md:mx-auto glass-header px-2 pt-2 pb-[max(0.6rem,env(safe-area-inset-bottom,0px))] flex items-center justify-around z-30 shadow-2xl rounded-t-3xl`}>
        <button 
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'home' 
              ? 'text-[#1769E0] font-extrabold bg-blue-500/10 shadow-xs' 
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-semibold'
          }`}
        >
          <Activity className="w-5 h-5" />
          <span className="text-[10px]">Home</span>
        </button>
        <button 
          onClick={() => setActiveTab('consultation')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'consultation' 
              ? 'text-[#1769E0] font-extrabold bg-blue-500/10 shadow-xs' 
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-semibold'
          }`}
        >
          <Stethoscope className="w-5 h-5" />
          <span className="text-[10px]">Consult</span>
        </button>
        <button 
          onClick={() => setActiveTab('tests')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'tests' 
              ? 'text-[#0FB5A0] font-extrabold bg-teal-500/10 shadow-xs' 
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-semibold'
          }`}
        >
          <Calendar className="w-5 h-5" />
          <span className="text-[10px]">Tests</span>
        </button>
        <button 
          onClick={() => setActiveTab('medicines')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'medicines' 
              ? 'text-[#10B981] font-extrabold bg-emerald-500/10 shadow-xs' 
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-semibold'
          }`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[10px]">Medicines</span>
        </button>
        <button 
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'profile' 
              ? 'text-[#1769E0] font-extrabold bg-blue-500/10 shadow-xs' 
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-semibold'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </nav>
    </div>
  );
};
