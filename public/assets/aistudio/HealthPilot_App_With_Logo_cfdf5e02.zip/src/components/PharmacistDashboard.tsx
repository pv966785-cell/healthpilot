import React, { useState, useEffect } from 'react';
import { useAuth, sanitizeFirestoreDoc } from '../context/AuthContext';
import { HealthPilotLogo } from './HealthPilotLogo';
import { PharmacistProfile, PharmacyOrder } from '../types';
import { collection, query, where, onSnapshot, setDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { 
  ShoppingBag, CheckCircle2, XCircle, AlertTriangle, Truck, 
  FileText, Clock, LogOut, Package, ArrowRight, ShieldCheck, Eye, X, AlertCircle, Loader2, Plus 
} from 'lucide-react';

interface PharmacyInventoryItem {
  id: string;
  pharmacyId: string;
  medicineId: string;
  medicineName: string;
  category: string;
  stockCount: number;
  price: number;
  expiryDate: string;
}

export const PharmacistDashboard: React.FC = () => {
  const { currentUser, logout, pharmacyOrders, dataLoading, updatePharmacyOrder } = useAuth();
  const pharma = currentUser as PharmacistProfile;

  const [inventory, setInventory] = useState<PharmacyInventoryItem[]>([]);
  const [inventoryLoading, setInventoryLoading] = useState<boolean>(true);
  const [isProcessingOrder, setIsProcessingOrder] = useState<boolean>(false);

  const [selectedRxOrder, setSelectedRxOrder] = useState<PharmacyOrder | null>(null);
  const [rejectReasonModal, setRejectReasonModal] = useState<PharmacyOrder | null>(null);
  const [rejectReasonText, setRejectReasonText] = useState('Prescription image is blurry or expired.');

  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const showToast = (msg: string, isError = false) => {
    setToastMessage({ text: msg, isError });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Real-time pharmacy inventory from Firestore
  useEffect(() => {
    if (!currentUser?.id) return;
    const q = query(collection(db, 'pharmacyInventory'), where('pharmacyId', '==', currentUser.id));
    const unsub = onSnapshot(q, (snapshot) => {
      const items: PharmacyInventoryItem[] = [];
      snapshot.forEach(docSnap => {
        items.push({ ...docSnap.data(), id: docSnap.id } as PharmacyInventoryItem);
      });
      setInventory(items);
      setInventoryLoading(false);
    }, (err) => {
      console.warn('pharmacyInventory subscription error:', err);
      setInventoryLoading(false);
    });
    return () => unsub();
  }, [currentUser?.id]);

  const handleSeedInventory = async () => {
    if (!currentUser?.id) return;
    setInventoryLoading(true);
    const standardItems = [
      { medicineId: 'med-1', medicineName: 'Glycomet-SR 500mg Tablet', category: 'Diabetes', stockCount: 140, price: 95, expiryDate: '12/2027' },
      { medicineId: 'med-2', medicineName: 'Pan-40 Tablet', category: 'General', stockCount: 85, price: 142, expiryDate: '09/2027' },
      { medicineId: 'med-3', medicineName: 'Shelcal 500mg Tablet', category: 'Wellness', stockCount: 210, price: 115, expiryDate: '03/2028' },
      { medicineId: 'med-4', medicineName: 'Liv.52 DS Syrup', category: 'Ayurveda', stockCount: 60, price: 150, expiryDate: '01/2028' }
    ];
    try {
      for (const item of standardItems) {
        const docId = `INV-${currentUser.id}-${item.medicineId}`;
        await setDoc(doc(db, 'pharmacyInventory', docId), sanitizeFirestoreDoc({
          id: docId,
          pharmacyId: currentUser.id,
          ...item
        }));
      }
      showToast('Pharmacy inventory initialized successfully!');
    } catch (err: any) {
      showToast(err?.message || 'Failed to initialize inventory.', true);
    } finally {
      setInventoryLoading(false);
    }
  };

  const handleApproveRx = async (orderId: string) => {
    if (isProcessingOrder) return;
    setIsProcessingOrder(true);
    try {
      await updatePharmacyOrder(orderId, { status: 'Packed' });
      setSelectedRxOrder(null);
      showToast(`Order ${orderId} verified & marked as PACKED`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to update order status.', true);
    } finally {
      setIsProcessingOrder(false);
    }
  };

  const handleRejectRx = async () => {
    if (!rejectReasonModal || isProcessingOrder) return;
    setIsProcessingOrder(true);
    try {
      await updatePharmacyOrder(rejectReasonModal.id, { status: 'Rejected', rejectionReason: rejectReasonText });
      setRejectReasonModal(null);
      showToast(`Order ${rejectReasonModal.id} rejected with reason logged.`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to reject order.', true);
    } finally {
      setIsProcessingOrder(false);
    }
  };

  const handleDispatchOrder = async (orderId: string) => {
    if (isProcessingOrder) return;
    setIsProcessingOrder(true);
    try {
      await updatePharmacyOrder(orderId, { status: 'Out for delivery', deliveryPartner: 'Rajesh Rider (+91 98110 55443)' });
      showToast(`Order ${orderId} handed over to delivery partner!`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to dispatch order.', true);
    } finally {
      setIsProcessingOrder(false);
    }
  };

  return (
    <div className="min-h-screen mesh-bg-light dark:mesh-bg-dark flex flex-col font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-6 right-6 z-50 ${toastMessage.isError ? 'bg-red-600 border-red-400' : 'bg-[#10B981] border-emerald-300'} text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-fade-in border`}>
          {toastMessage.isError ? <AlertCircle className="w-5 h-5 text-white shrink-0" /> : <CheckCircle2 className="w-5 h-5 text-white shrink-0" />}
          <span className="text-sm font-semibold">{toastMessage.text}</span>
        </div>
      )}

      {/* Header */}
      <header className="glass-header px-6 py-3.5 flex items-center justify-between sticky top-0 z-40 shadow-xs">
        <div className="flex items-center gap-3">
          <HealthPilotLogo size="sm" />
          <span className="text-xs font-extrabold bg-emerald-50 dark:bg-emerald-950/60 text-[#10B981] px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-800 flex items-center gap-1.5 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" /> Pharmacy Dispensation Hub
          </span>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <span className="text-xs font-extrabold text-slate-900 dark:text-white block leading-none">{pharma.pharmacyName || 'Apollo Medicos'}</span>
            <span className="text-[10px] text-slate-400 font-semibold">DL: {pharma.drugLicenceNumber || 'DL-20B-99120'}</span>
          </div>

          <button
            onClick={logout}
            className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-6 space-y-6">
        {/* Pharmacy Top Banner */}
        <div className="bg-gradient-to-r from-[#10B981] via-emerald-600 to-[#0B2A6F] text-white p-6 rounded-[32px] shadow-xl shadow-emerald-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative overflow-hidden">
          <div className="space-y-1 relative z-10">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-extrabold uppercase tracking-widest bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/25">
                GSTIN: {pharma.gstNumber || '09AAACA1234F1Z5'}
              </span>
              <span className="text-xs text-emerald-100 font-extrabold">Active Dispensing Partner</span>
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight">{pharma.pharmacyName || 'Apollo Medicos & Healthcare Hub'}</h2>
            <p className="text-xs text-emerald-100 mt-1">
              {pharma.pharmacyAddress || 'Sector 63, Noida, Uttar Pradesh'}
            </p>
          </div>

          <div className="flex gap-3 relative z-10">
            <div className="bg-white/15 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/25 text-center shadow-inner">
              <span className="text-[10px] text-emerald-100 uppercase block font-semibold">Rx Pending Verification</span>
              <strong className="text-xl font-extrabold">{pharmacyOrders.filter(o => o.status === 'Placed').length} Orders</strong>
            </div>
            <div className="bg-white/15 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/25 text-center shadow-inner">
              <span className="text-[10px] text-emerald-100 uppercase block font-semibold">Ready for Dispatch</span>
              <strong className="text-xl font-extrabold">{pharmacyOrders.filter(o => o.status === 'Packed').length} Orders</strong>
            </div>
          </div>
        </div>

        {/* Prescription Verification Queue (Crucial Compliance Requirement) */}
        <div className="bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800/90 rounded-[32px] p-6 shadow-sm backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Prescription (Rx) Verification Queue
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Scheduled under Pharmacy Act regulations: verify doctor signature & matching salt before packing.</p>
            </div>
            <span className="text-xs font-bold text-[#10B981] bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-3 py-1 rounded-xl">
              Mandatory Pharmacist Sign-Off
            </span>
          </div>

          <div className="space-y-3">
            {dataLoading ? (
              <div className="py-12 flex flex-col items-center justify-center text-slate-400 gap-2">
                <Loader2 className="w-8 h-8 animate-spin text-[#10B981]" />
                <span className="text-xs font-semibold">Syncing pharmacy orders...</span>
              </div>
            ) : pharmacyOrders.length === 0 ? (
              <div className="py-12 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-6">
                <Package className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">No medicine orders yet</h4>
                <p className="text-xs text-slate-500 mt-1">When patients place medicine orders with your pharmacy, they will appear here in real time.</p>
              </div>
            ) : (
              pharmacyOrders.map((ord) => (
              <div
                key={ord.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-800/40 backdrop-blur-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:shadow-md transition-all"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">{ord.id}</span>
                    <span className="text-xs font-bold text-slate-500">• {ord.patientName}</span>
                    <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${
                      ord.status === 'Placed' ? 'status-badge-pending' :
                      ord.status === 'Packed' ? 'status-badge-info' :
                      ord.status === 'Out for delivery' ? 'status-badge-approved' :
                      ord.status === 'Delivered' ? 'status-badge-completed' :
                      'status-badge-cancelled'
                    }`}>
                      {ord.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                    Items: {ord.items.map(i => `${i.medicineName} (x${i.quantity})`).join(', ')}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Delivery Address: {ord.deliveryAddress} • Amount: <strong>₹{ord.totalAmount}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {ord.status === 'Placed' && (
                    <>
                      <button
                        onClick={() => setSelectedRxOrder(ord)}
                        className="px-3.5 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" /> View Rx
                      </button>
                      <button
                        disabled={isProcessingOrder}
                        onClick={() => handleApproveRx(ord.id)}
                        className="px-3.5 py-2 bg-gradient-to-r from-[#10B981] to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all disabled:opacity-50"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Approve & Pack
                      </button>
                      <button
                        disabled={isProcessingOrder}
                        onClick={() => setRejectReasonModal(ord)}
                        className="px-3.5 py-2 bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold rounded-xl transition-colors disabled:opacity-50"
                      >
                        Reject
                      </button>
                    </>
                  )}
                  {ord.status === 'Packed' && (
                    <button
                      disabled={isProcessingOrder}
                      onClick={() => handleDispatchOrder(ord.id)}
                      className="px-4 py-2 bg-gradient-to-r from-[#1769E0] to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md shadow-blue-500/20 transition-all disabled:opacity-50"
                    >
                      <Truck className="w-4 h-4" /> Dispatch with Delivery Partner
                    </button>
                  )}
                  {ord.status === 'Out for delivery' && (
                    <span className="text-xs font-bold text-teal-600 flex items-center gap-1">
                      <Truck className="w-4 h-4" /> En route with {ord.deliveryPartner}
                    </span>
                  )}
                </div>
              </div>
            )))}
          </div>
        </div>

        {/* Stock & Expiry Alerts Section from Firestore pharmacyInventory */}
        <div className="bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800/90 rounded-[32px] p-6 shadow-sm backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Pharmacy Inventory Stock & Expiry Radar
              </h3>
              <p className="text-xs text-slate-500">Live stock records from Firestore (collection: pharmacyInventory)</p>
            </div>
            {inventory.length === 0 && !inventoryLoading && (
              <button
                onClick={handleSeedInventory}
                className="px-3 py-1.5 bg-[#10B981] hover:bg-emerald-600 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-sm transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> Initialize Stock Catalog
              </button>
            )}
          </div>

          {inventoryLoading ? (
            <div className="py-8 flex flex-col items-center justify-center text-slate-400 gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-[#10B981]" />
              <span className="text-xs">Loading pharmacy stock...</span>
            </div>
          ) : inventory.length === 0 ? (
            <div className="py-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-6">
              <Package className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-xs text-slate-500">No stock tracked in pharmacyInventory yet.</p>
              <button
                onClick={handleSeedInventory}
                className="mt-3 px-4 py-2 bg-gradient-to-r from-[#10B981] to-emerald-600 text-white text-xs font-bold rounded-xl"
              >
                Populate Initial Stock
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {inventory.map((med) => (
                <div key={med.id} className="p-4 bg-white/70 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 hover:shadow-sm transition-all">
                  <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">{med.category}</span>
                  <h4 className="font-extrabold text-xs text-slate-900 dark:text-white mt-1.5">{med.medicineName}</h4>
                  <div className="mt-2 text-xs flex justify-between">
                    <span className="text-slate-400">Stock Count:</span>
                    <strong className={med.stockCount < 90 ? 'text-amber-500' : 'text-slate-900 dark:text-white'}>{med.stockCount} Units</strong>
                  </div>
                  <div className="text-xs flex justify-between mt-1">
                    <span className="text-slate-400">Price:</span>
                    <span className="text-emerald-600 font-bold text-[11px]">₹{med.price}</span>
                  </div>
                  <div className="text-xs flex justify-between mt-1">
                    <span className="text-slate-400">Expiry Date:</span>
                    <span className="text-slate-700 dark:text-slate-300 font-mono text-[11px]">{med.expiryDate}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Prescription Inspection Modal */}
      {selectedRxOrder && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-[36px] p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-extrabold text-base">Prescription Verification #{selectedRxOrder.id}</h3>
              <button onClick={() => setSelectedRxOrder(null)} className="p-1 rounded-full hover:bg-slate-100"><X className="w-5 h-5" /></button>
            </div>

            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl mb-4 text-xs">
              <span className="font-bold text-emerald-800 dark:text-emerald-300 block mb-1">Prescribed Clinical Verification</span>
              <p className="text-slate-600 dark:text-slate-300">
                Patient: <strong>{selectedRxOrder.patientName}</strong> • Phone: <strong>{selectedRxOrder.patientPhone}</strong>
              </p>
              <div className="mt-3 p-3 bg-white dark:bg-slate-800 rounded-xl border border-dashed border-emerald-300 text-center">
                <FileText className="w-10 h-10 text-[#10B981] mx-auto mb-1" />
                <span className="font-mono text-[11px] text-slate-700 dark:text-slate-200 block font-bold">Prescription_Dr_Mukherjee_Signed.jpg</span>
                <span className="text-[10px] text-emerald-600 font-semibold">Doctor DMC Council Seal & Signature Verified</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => handleApproveRx(selectedRxOrder.id)}
                className="flex-1 py-3 bg-gradient-to-r from-[#10B981] to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/25 transition-all"
              >
                Approve & Pack Medicines
              </button>
              <button
                onClick={() => {
                  const ord = selectedRxOrder;
                  setSelectedRxOrder(null);
                  setRejectReasonModal(ord);
                }}
                className="px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold"
              >
                Reject Rx
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Modal */}
      {rejectReasonModal && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[32px] p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="font-extrabold text-base text-red-600 mb-2">Reject Prescription</h3>
            <p className="text-xs text-slate-500 mb-4">Please provide a clinical reason so the patient can re-upload:</p>
            <textarea
              rows={3}
              value={rejectReasonText}
              onChange={e => setRejectReasonText(e.target.value)}
              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs mb-4"
            />
            <div className="flex gap-2">
              <button
                onClick={handleRejectRx}
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl text-xs font-bold"
              >
                Confirm Rejection
              </button>
              <button
                onClick={() => setRejectReasonModal(null)}
                className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
