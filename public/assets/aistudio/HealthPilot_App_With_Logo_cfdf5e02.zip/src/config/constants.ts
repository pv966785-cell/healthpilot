// TODO: Update to the new HealthPilot support email
export const CONTACT_EMAIL = 'mediisphere@gmail.com';
