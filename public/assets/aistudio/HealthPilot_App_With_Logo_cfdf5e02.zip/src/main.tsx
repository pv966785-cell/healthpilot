import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import './firebase.ts';

// Type definition for beforeinstallprompt event
interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

declare global {
  interface Window {
    deferredPrompt?: BeforeInstallPromptEvent | null;
  }
}

// Listen for the "beforeinstallprompt" event as early as possible,
// prevent default browser mini-infobar, store on window, and notify components
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  window.deferredPrompt = e as BeforeInstallPromptEvent;
  window.dispatchEvent(new CustomEvent('healthpilot:beforeinstallprompt'));
});

window.addEventListener('appinstalled', () => {
  window.deferredPrompt = null;
  window.dispatchEvent(new CustomEvent('healthpilot:appinstalled'));
});

createRoot(document.getElementById('root')!).render(<App />);
