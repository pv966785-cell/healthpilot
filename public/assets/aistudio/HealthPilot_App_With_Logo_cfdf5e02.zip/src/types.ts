export type UserRole = 'patient' | 'doctor' | 'pharmacist' | 'lab' | 'super_admin' | 'sub_admin';
export type UserStatus = 'Active' | 'Pending' | 'Suspended' | 'Blocked';

export interface BaseUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  status: UserStatus;
  password?: string;
  failedAttempts?: number;
  lockedUntil?: number;
  avatarUrl?: string;
  rating?: number;
  reviewCount?: number;
  createdAt: string;
  lastLogin?: string;
  ipAddress?: string;
  device?: string;
  rejectionReason?: string;
}

export interface PatientProfile extends BaseUser {
  role: 'patient';
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string;
  allergies: string[];
  chronicConditions: string[];
  address: string;
  walletBalance: number;
  familyMembers: FamilyMember[];
}

export interface DoctorProfile extends BaseUser {
  role: 'doctor';
  specialty: string;
  qualification: string;
  experienceYears: number;
  councilRegistrationNumber: string;
  hospitalOrClinic: string;
  clinicAddress: string;
  consultationFee: number;
  languages: string[];
  bio: string;
  rating: number;
  reviewCount: number;
  isAvailableNow: boolean;
  documents: {
    degreeUrl?: string;
    licenceUrl?: string;
    photoUrl?: string;
  };
  rejectionReason?: string;
}

export interface PharmacistProfile extends BaseUser {
  role: 'pharmacist';
  pharmacyName: string;
  drugLicenceNumber: string;
  gstNumber: string;
  pharmacyAddress: string;
  documents: {
    licenceUrl?: string;
    gstCertUrl?: string;
  };
  rejectionReason?: string;
}

export interface LabProfile extends BaseUser {
  role: 'lab';
  labName: string;
  accreditation: 'NABL' | 'CAP' | 'ISO' | 'State Certified';
  licenceNumber: string;
  labAddress: string;
  documents: {
    accreditationCertUrl?: string;
    licenceUrl?: string;
  };
  rejectionReason?: string;
}

export interface AdminProfile extends BaseUser {
  role: 'super_admin' | 'sub_admin';
  twoFactorEnabled: boolean;
  failedAttempts: number;
  lockedUntil?: number;
  assignedRoleName?: string;
}

export type AppUser = PatientProfile | DoctorProfile | PharmacistProfile | LabProfile | AdminProfile;

export interface FamilyMember {
  id: string;
  name: string;
  relation: 'Father' | 'Mother' | 'Spouse' | 'Son' | 'Daughter' | 'Self';
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string;
}

export interface LabTest {
  id: string;
  name: string;
  category: string;
  price: number;
  discountPrice: number;
  discountedPrice: number;
  originalPrice: number;
  labRate: number;
  vial: string;
  sampleType: string;
  tat: string;
  reportHours: number;
  reportTimeHours: number;
  parameters: number;
  parametersCount: number;
  fastingRequired: boolean;
  description: string;
  includes?: string[];
  isPanel: boolean;
  active: boolean;
  popular?: boolean;
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  qualification: string;
  experienceYears: number;
  hospital: string;
  rating: number;
  reviewCount: number;
  consultationFee: number;
  languages: string[];
  nextAvailableSlot: string;
  avatarUrl: string;
  bio: string;
}

export interface Medicine {
  id: string;
  name: string;
  salt: string;
  category: 'Diabetes' | 'Heart' | 'Ayurveda' | 'Baby care' | 'Wellness' | 'Devices' | 'General';
  price: number;
  discountPrice: number;
  requiresRx: boolean;
  manufacturer: string;
  uses: string;
  sideEffects: string;
  substitutes: string[];
  inStock: boolean;
  stockCount: number;
  expiryDate: string;
  imageUrl: string;
}

export interface LabBooking {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  testId: string;
  testName: string;
  collectionType: 'Home Collection' | 'Lab Visit';
  dateTime: string;
  address: string;
  status: 'Confirmed' | 'Phlebotomist Assigned' | 'Collected' | 'In lab' | 'Processing' | 'Report ready';
  assignedLabId: string;
  assignedPhlebotomist?: string;
  amount: number;
  reportUrl?: string;
  summary?: { normalCount: number; abnormalCount: number; status: 'Normal' | 'Needs Attention' };
}

export interface DoctorAppointment {
  id: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  doctorSpecialty: string;
  doctorId: string;
  doctorName: string;
  mode: 'Video' | 'Audio' | 'Chat' | 'Clinic visit';
  dateTime: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  fee: number;
  symptoms?: string;
  prescription?: DigitalPrescription;
}

export interface DigitalPrescription {
  id: string;
  appointmentId: string;
  patientName: string;
  doctorName: string;
  doctorSpecialty: string;
  doctorCouncilNo: string;
  date: string;
  vitals: { bp: string; pulse: string; weight: string; temp: string };
  diagnosis: string;
  medicines: {
    name: string;
    dosage: string;
    duration: string;
    instructions: string;
  }[];
  testsAdvised: string[];
  dietAdvice: string;
  signatureSvg: string;
}

export interface PharmacyOrder {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  pharmacyId: string;
  items: { medicineId: string; medicineName: string; quantity: number; price: number }[];
  totalAmount: number;
  status: 'Placed' | 'Verified' | 'Packed' | 'Out for delivery' | 'Delivered' | 'Rejected';
  orderDate: string;
  deliveryAddress: string;
  rxAttached: boolean;
  rxImageUrl?: string;
  deliveryPartner?: string;
  rejectionReason?: string;
}

export interface HealthRecord {
  id: string;
  title: string;
  type: 'Prescription' | 'Lab Report' | 'Vaccination' | 'Invoice';
  date: string;
  doctorOrLab: string;
  fileSize: string;
  url: string;
}

export interface RBACPermission {
  module: string;
  view: boolean;
  create: boolean;
  edit: boolean;
  delete: boolean;
  export: boolean;
  approve: boolean;
}

export interface AdminRoleConfig {
  roleId: string;
  roleName: string;
  description: string;
  permissions: RBACPermission[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  adminName: string;
  action: string;
  module: string;
  ipAddress: string;
  device?: string;
  details: string;
}

export interface SupportTicket {
  id: string;
  userName: string;
  category: 'Lab Booking' | 'Doctor Consultation' | 'Medicine Delivery' | 'Refund & Payment';
  subject: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  createdAt: string;
}

export interface FounderInfo {
  name: string;
  role: string;
  phone: string;
  email: string;
  address: string;
  office: string;
}
